﻿using System;
using System.Windows.Forms;

namespace RNX_Market
{
    public partial class Inventory_form : Form
    {
        public Inventory_form()
        {
            InitializeComponent();
        }
        //Back Button which saves every textboxes
        private void Back_Inventory_Click(object sender, EventArgs e)
        {
            new Main().Show();
            this.Hide();
            Properties.Settings.Default.Apple_txt = Apple_txt.Text;
            Properties.Settings.Default.Banana_txt = Banana_txt.Text;
            Properties.Settings.Default.Kiwi_txt = Kiwi_txt.Text;
            Properties.Settings.Default.Orange_txt = Orange_txt.Text;
            Properties.Settings.Default.Pineapple_txt = Pineapple_txt.Text;
            Properties.Settings.Default.Peach_txt = Peach_txt.Text;
            Properties.Settings.Default.Cherry_txt = Cherry_txt.Text;
            Properties.Settings.Default.Mango_txt = Mango_txt.Text;
            Properties.Settings.Default.Grape_txt = Grape_txt.Text;
            Properties.Settings.Default.Strawberry_txt = Strawberry_txt.Text;
            Properties.Settings.Default.Mandarin_txt = Mandarin_txt.Text;
            Properties.Settings.Default.Pear_txt = Pear_txt.Text;
            Properties.Settings.Default.Potato_txt = Potato_txt.Text;
            Properties.Settings.Default.Carrot_txt = Carrot_txt.Text;
            Properties.Settings.Default.Corn_txt = Corn_txt.Text;
            Properties.Settings.Default.Tomato_txt = Tomato_txt.Text;
            Properties.Settings.Default.Cucumber_txt = Cucumber_txt.Text;
            Properties.Settings.Default.Lettuce_txt = Lettuce_txt.Text;
            Properties.Settings.Default.Broccoli_txt = Broccoli_txt.Text;
            Properties.Settings.Default.Soy_txt = Soy_txt.Text;
            Properties.Settings.Default.Bean_txt = Bean_txt.Text;
            Properties.Settings.Default.Celery_txt = Celery_txt.Text;
            Properties.Settings.Default.Cabbage_txt = Cabbage_txt.Text;
            Properties.Settings.Default.Pumpkin_txt = Pumpkin_txt.Text;

            Properties.Settings.Default.Save();
        }
        // Validations
        private void Apple_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Banana_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Kiwi_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Orange_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Pineapple_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Peach_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Cherry_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Mango_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Grape_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Strawberry_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Mandarin_txt_KeyPress(object sender, KeyPressEventArgs e)
        {

        }
        private void Pear_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Potato_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Carrot_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Corn_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Tomato_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Cucumber_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Lettuce_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Broccoli_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Soy_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Bean_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Celery_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Cabbage_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        private void Pumpkin_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        //Saving Textboxes 
        private void Inventory_form_FormClosed(object sender, FormClosedEventArgs e)
        {
            Properties.Settings.Default.Apple_txt = Apple_txt.Text;
            Properties.Settings.Default.Banana_txt = Banana_txt.Text;
            Properties.Settings.Default.Kiwi_txt = Kiwi_txt.Text;
            Properties.Settings.Default.Orange_txt = Orange_txt.Text;
            Properties.Settings.Default.Pineapple_txt = Pineapple_txt.Text;
            Properties.Settings.Default.Peach_txt = Peach_txt.Text;
            Properties.Settings.Default.Cherry_txt = Cherry_txt.Text;
            Properties.Settings.Default.Mango_txt = Mango_txt.Text;
            Properties.Settings.Default.Grape_txt = Grape_txt.Text;
            Properties.Settings.Default.Strawberry_txt = Strawberry_txt.Text;
            Properties.Settings.Default.Mandarin_txt = Mandarin_txt.Text;
            Properties.Settings.Default.Pear_txt = Pear_txt.Text;
            Properties.Settings.Default.Potato_txt = Potato_txt.Text;
            Properties.Settings.Default.Carrot_txt = Carrot_txt.Text;
            Properties.Settings.Default.Corn_txt = Corn_txt.Text;
            Properties.Settings.Default.Tomato_txt = Tomato_txt.Text;
            Properties.Settings.Default.Cucumber_txt = Cucumber_txt.Text;
            Properties.Settings.Default.Lettuce_txt = Lettuce_txt.Text;
            Properties.Settings.Default.Broccoli_txt = Broccoli_txt.Text;
            Properties.Settings.Default.Soy_txt = Soy_txt.Text;
            Properties.Settings.Default.Bean_txt = Bean_txt.Text;
            Properties.Settings.Default.Celery_txt = Celery_txt.Text;
            Properties.Settings.Default.Cabbage_txt = Cabbage_txt.Text;
            Properties.Settings.Default.Pumpkin_txt = Pumpkin_txt.Text;

            Properties.Settings.Default.Save();
        }

        private void Inventory_form_Load(object sender, EventArgs e)
        {
            Apple_txt.Text = Properties.Settings.Default.Apple_txt;
            Banana_txt.Text = Properties.Settings.Default.Banana_txt;
            Kiwi_txt.Text = Properties.Settings.Default.Kiwi_txt;
            Orange_txt.Text = Properties.Settings.Default.Orange_txt;
            Pineapple_txt.Text = Properties.Settings.Default.Pineapple_txt;
            Peach_txt.Text = Properties.Settings.Default.Peach_txt;
            Cherry_txt.Text = Properties.Settings.Default.Cherry_txt;
            Mango_txt.Text = Properties.Settings.Default.Mango_txt;
            Grape_txt.Text = Properties.Settings.Default.Grape_txt;
            Strawberry_txt.Text = Properties.Settings.Default.Strawberry_txt;
            Mandarin_txt.Text = Properties.Settings.Default.Mandarin_txt;
            Pear_txt.Text = Properties.Settings.Default.Pear_txt;
            Potato_txt.Text = Properties.Settings.Default.Potato_txt;
            Carrot_txt.Text = Properties.Settings.Default.Carrot_txt;
            Corn_txt.Text = Properties.Settings.Default.Corn_txt;
            Tomato_txt.Text = Properties.Settings.Default.Tomato_txt;
            Cucumber_txt.Text = Properties.Settings.Default.Cucumber_txt;
            Lettuce_txt.Text = Properties.Settings.Default.Lettuce_txt;
            Broccoli_txt.Text = Properties.Settings.Default.Broccoli_txt;
            Soy_txt.Text = Properties.Settings.Default.Soy_txt;
            Bean_txt.Text = Properties.Settings.Default.Bean_txt;
            Celery_txt.Text = Properties.Settings.Default.Celery_txt;
            Cabbage_txt.Text = Properties.Settings.Default.Cabbage_txt;
            Pumpkin_txt.Text = Properties.Settings.Default.Pumpkin_txt;
        }

        //Adding And Removing

        private void Add_Apple_Click(object sender, EventArgs e)
        {
            var add_Apple = Convert.ToInt32(Apple_txt.Text);
            add_Apple++;
            Apple_txt.Text = add_Apple.ToString();
        }

        private void Remove_Apple_Click(object sender, EventArgs e)
        {
            var Remove_Apple = Convert.ToInt32(Apple_txt.Text);
            if (Remove_Apple == 0)
            {
                MessageBox.Show("Oops there are no Apple's left");

            }
            else
            {
                Remove_Apple = Remove_Apple - 1;
                Apple_txt.Text = Remove_Apple.ToString();
            }
        }
     

        private void Add_Banana_Click(object sender, EventArgs e)
        {
            var add_Banana = Convert.ToInt32(Banana_txt.Text);
            add_Banana++;
            Banana_txt.Text = add_Banana.ToString();
        }

        private void Remove_Banana_Click(object sender, EventArgs e)
        {
            var Remove_Banana = Convert.ToInt32(Banana_txt.Text);

            if (Remove_Banana == 0)
            {
                MessageBox.Show("Oops there are no Banana's left");
            }
            else
            {
                Remove_Banana = Remove_Banana - 1;
                Banana_txt.Text = Remove_Banana.ToString();
            }
        }
        private void Add_Kiwi_Click(object sender, EventArgs e)
        {
            var add_Kiwi= Convert.ToInt32(Kiwi_txt.Text);
            add_Kiwi++;
            Kiwi_txt.Text = add_Kiwi.ToString();
        }

        private void Remove_Kiwi_Click(object sender, EventArgs e)
        {
            var Remove_Kiwi = Convert.ToInt32(Kiwi_txt.Text);
            if (Remove_Kiwi == 0)
            {
                MessageBox.Show("Oops there are no Kiwi's left");

            }
            else
            {
                Remove_Kiwi = Remove_Kiwi - 1;
                Kiwi_txt.Text = Remove_Kiwi.ToString();
            }
        }
        private void Add_Orange_Click(object sender, EventArgs e)
        {
            var add_Orange = Convert.ToInt32(Orange_txt.Text);
            add_Orange++;
            Orange_txt.Text = add_Orange.ToString();
        }

        private void Remove_Orange_Click(object sender, EventArgs e)
        {
            var Remove_Orange = Convert.ToInt32(Orange_txt.Text);
            if (Remove_Orange == 0)
            {
                MessageBox.Show("Oops there are no Orange's left");

            }
            else
            {
                Remove_Orange = Remove_Orange - 1;
                Orange_txt.Text = Remove_Orange.ToString();
            }
        }

        private void Add_Pineapple_Click(object sender, EventArgs e)
        {
            var add_Pineapple = Convert.ToInt32(Pineapple_txt.Text);
            add_Pineapple++;
            Pineapple_txt.Text = add_Pineapple.ToString();
        }
        private void Remove_Pineapple_Click(object sender, EventArgs e)
        {
            var Remove_Pineapple = Convert.ToInt32(Pineapple_txt.Text);
            if (Remove_Pineapple == 0)
            {
                MessageBox.Show("Oops there are no Pineapple's left");

            }
            else
            {
                Remove_Pineapple = Remove_Pineapple - 1;
                Pineapple_txt.Text = Remove_Pineapple.ToString();
            }
        }

        private void Add_Peach_Click(object sender, EventArgs e)
        {
            var add_Peach = Convert.ToInt32(Peach_txt.Text);
            add_Peach++;
            Peach_txt.Text = add_Peach.ToString();
        }

        private void Remove_Peach_Click(object sender, EventArgs e)
        {
            var Remove_Peach = Convert.ToInt32(Peach_txt.Text);
            if (Remove_Peach == 0)
            {
                MessageBox.Show("Oops there are no Peach's left");

            }
            else
            {
                Remove_Peach = Remove_Peach - 1;
                Peach_txt.Text = Remove_Peach.ToString();
            }
        }

        private void Add_Cherry_Click(object sender, EventArgs e)
        {
            var add_Cherry = Convert.ToInt32(Cherry_txt.Text);
            add_Cherry++;
            Cherry_txt.Text = add_Cherry.ToString();
        }

        private void Remove_Cherry_Click(object sender, EventArgs e)
        {
            var Remove_Cherry = Convert.ToInt32(Cherry_txt.Text);
            if (Remove_Cherry == 0)
            {
                MessageBox.Show("Oops there are no Cherry's left");

            }
            else
            {
                Remove_Cherry = Remove_Cherry - 1;
                Cherry_txt.Text = Remove_Cherry.ToString();
            }
        }

        private void Add_Mango_Click(object sender, EventArgs e)
        {
            var add_Mango = Convert.ToInt32(Mango_txt.Text);
            add_Mango++;
            Mango_txt.Text = add_Mango.ToString();
        }

       private void Remove_Mango_Click(object sender, EventArgs e)
        {
            var Remove_Mango = Convert.ToInt32(Mango_txt.Text);
            if (Remove_Mango == 0)
            {
                MessageBox.Show("Oops there are no Mango's left");

            }
            else
            {
                Remove_Mango = Remove_Mango - 1;
                Mango_txt.Text = Remove_Mango.ToString();
            }
        }


        private void Add_Grape_Click(object sender, EventArgs e)
        {
            var add_Grape = Convert.ToInt32(Grape_txt.Text);
            add_Grape++;
            Grape_txt.Text = add_Grape.ToString();
        }

        private void Remove_Grape_Click(object sender, EventArgs e)
        {
            var Remove_Grape = Convert.ToInt32(Grape_txt.Text);
            if (Remove_Grape == 0)
            {
                MessageBox.Show("Oops there are no Grape's left");

            }
            else
            {
                Remove_Grape = Remove_Grape - 1;
                Grape_txt.Text = Remove_Grape.ToString();
            }
        }

        private void Add_Strawberry_Click(object sender, EventArgs e)
        {
            var add_Strawberry = Convert.ToInt32(Strawberry_txt.Text);
            add_Strawberry++;
            Strawberry_txt.Text = add_Strawberry.ToString();
        }

        private void Remove_Strawberry_Click(object sender, EventArgs e)
        {
            var Remove_Strawberry = Convert.ToInt32(Strawberry_txt.Text);
            if (Remove_Strawberry == 0)
            {
                MessageBox.Show("Oops there are no Strawberry's left");

            }
            else
            {
                Remove_Strawberry = Remove_Strawberry - 1;
                Strawberry_txt.Text = Remove_Strawberry.ToString();
            }
        }

        private void Add_Mandarin_Click(object sender, EventArgs e)
        {
            var add_Mandarin = Convert.ToInt32(Mandarin_txt.Text);
            add_Mandarin++;
            Mandarin_txt.Text = add_Mandarin.ToString();
        }


        private void Remove_Mandarin_Click(object sender, EventArgs e)
        {
            var Remove_Mandarin = Convert.ToInt32(Mandarin_txt.Text);
            if (Remove_Mandarin == 0)
            {
                MessageBox.Show("Oops there are no Mandarin's left");

            }
            else
            {
                Remove_Mandarin = Remove_Mandarin - 1;
                Mandarin_txt.Text = Remove_Mandarin.ToString();
            }
        }

        private void Add_Pear_Click(object sender, EventArgs e)
        {
            var add_Pear = Convert.ToInt32(Pear_txt.Text);
            add_Pear++;
            Pear_txt.Text = add_Pear.ToString();
        }

        private void Remove_Pear_Click(object sender, EventArgs e)
        {
            var Remove_Pear = Convert.ToInt32(Pear_txt.Text);
            if (Remove_Pear == 0)
            {
                MessageBox.Show("Oops there are no Pear's left");

            }
            else
            {
                Remove_Pear = Remove_Pear - 1;
                Pear_txt.Text = Remove_Pear.ToString();
            }
        }


        private void Add_Potato_Click(object sender, EventArgs e)
        {
            var add_Potato = Convert.ToInt32(Potato_txt.Text);
            add_Potato++;
            Potato_txt.Text = add_Potato.ToString();
        }

        private void Remove_Potato_Click(object sender, EventArgs e)
        {
            var Remove_Potato = Convert.ToInt32(Potato_txt.Text);
            if (Remove_Potato == 0)
            {
                MessageBox.Show("Oops there are no Potato's left");

            }
            else
            {
                Remove_Potato = Remove_Potato - 1;
                Potato_txt.Text = Remove_Potato.ToString();
            }
        }

        private void Add_Carrot_Click(object sender, EventArgs e)
        {
            var add_Carrot = Convert.ToInt32(Carrot_txt.Text);
            add_Carrot++;
            Carrot_txt.Text = add_Carrot.ToString();
        }

        private void Remove_Carrot_Click(object sender, EventArgs e)
        {
            var Remove_Carrot = Convert.ToInt32(Carrot_txt.Text);
            if (Remove_Carrot == 0)
            {
                MessageBox.Show("Oops there are no Carrot's left");

            }
            else
            {
                Remove_Carrot = Remove_Carrot - 1;
                Carrot_txt.Text = Remove_Carrot.ToString();
            }
        }
        private void Add_Corn_Click(object sender, EventArgs e)
        {
            var add_Corn = Convert.ToInt32(Corn_txt.Text);
            add_Corn++;
            Corn_txt.Text = add_Corn.ToString();
        }


        private void Remove_Corn_Click(object sender, EventArgs e)
        {
            var Remove_Corn = Convert.ToInt32(Corn_txt.Text);
            if (Remove_Corn == 0)
            {
                MessageBox.Show("Oops there are no Corn's left");

            }
            else
            {
                Remove_Corn = Remove_Corn - 1;
                Corn_txt.Text = Remove_Corn.ToString();
            }
        }

        private void Add_Tomato_Click(object sender, EventArgs e)
        {
            var add_Tomato = Convert.ToInt32(Tomato_txt.Text);
            add_Tomato++;
            Tomato_txt.Text = add_Tomato.ToString();
        }


        private void Remove_Tomato_Click(object sender, EventArgs e)
        {
            var Remove_Tomato = Convert.ToInt32(Tomato_txt.Text);
            if (Remove_Tomato == 0)
            {
                MessageBox.Show("Oops there are no Tomato's left");

            }
            else
            {
                Remove_Tomato = Remove_Tomato - 1;
                Tomato_txt.Text = Remove_Tomato.ToString();
            }

        }

        private void Add_Cucumber_Click(object sender, EventArgs e)
        {
            var add_Cucumber = Convert.ToInt32(Cucumber_txt.Text);
            add_Cucumber++;
            Cucumber_txt.Text = add_Cucumber.ToString();
        }

        private void Remove_Cucumber_Click(object sender, EventArgs e)
        {
            var Remove_Cucumber = Convert.ToInt32(Cucumber_txt.Text);
            if (Remove_Cucumber == 0)
            {
                MessageBox.Show("Oops there are no Cucumber's left");

            }
            else
            {
                Remove_Cucumber = Remove_Cucumber - 1;
                Cucumber_txt.Text = Remove_Cucumber.ToString();
            }
        }

        private void Add_Broccoli_Click(object sender, EventArgs e)
        {
            var add_Broccoli = Convert.ToInt32(Broccoli_txt.Text);
            add_Broccoli++;
            Broccoli_txt.Text = add_Broccoli.ToString();
        }

        private void Remove_Broccoli_Click(object sender, EventArgs e)
        {
            var Remove_Broccoli = Convert.ToInt32(Broccoli_txt.Text);
            if (Remove_Broccoli == 0)
            {
                MessageBox.Show("Oops there are no Broccoli's left");

            }
            else
            {
                Remove_Broccoli = Remove_Broccoli - 1;
                Broccoli_txt.Text = Remove_Broccoli.ToString();
            }
        }

        private void Add_Soy_Click(object sender, EventArgs e)
        {
            var add_Soy = Convert.ToInt32(Soy_txt.Text);
            add_Soy++;
            Soy_txt.Text = add_Soy.ToString();
        }

        private void Remove_Soy_Click(object sender, EventArgs e)
        {
            var Remove_Soy = Convert.ToInt32(Soy_txt.Text);
            if (Remove_Soy == 0)
            {
                MessageBox.Show("Oops there are no Soy's left");

            }
            else
            {
                Remove_Soy = Remove_Soy - 1;
                Soy_txt.Text = Remove_Soy.ToString();
            }
        }

        private void Add_Bean_Click(object sender, EventArgs e)
        {
            var add_Bean = Convert.ToInt32(Bean_txt.Text);
            add_Bean++;
            Bean_txt.Text = add_Bean.ToString();
        }

        private void Remove_Bean_Click(object sender, EventArgs e)
        {
            var Remove_Bean = Convert.ToInt32(Bean_txt.Text);
            if (Remove_Bean == 0)
            {
                MessageBox.Show("Oops there are no Bean's left");

            }
            else
            {
                Remove_Bean = Remove_Bean - 1;
                Bean_txt.Text = Remove_Bean.ToString();
            }
        }

        private void Add_Celery_Click(object sender, EventArgs e)
        {
            var add_Celery = Convert.ToInt32(Celery_txt.Text);
            add_Celery++;
            Celery_txt.Text = add_Celery.ToString();
        }

        private void Remove_Celery_Click(object sender, EventArgs e)
        {
            var Remove_Celery = Convert.ToInt32(Celery_txt.Text);
            if (Remove_Celery == 0)
            {
                MessageBox.Show("Oops there are no Celery's left");

            }
            else
            {
                Remove_Celery = Remove_Celery - 1;
                Celery_txt.Text = Remove_Celery.ToString();
            }
        }

        private void Add_Cabbage_Click(object sender, EventArgs e)
        {
            var add_Cabbage = Convert.ToInt32(Cabbage_txt.Text);
            add_Cabbage++;
            Cabbage_txt.Text = add_Cabbage.ToString();
        }

        private void Remove_Cabbage_Click(object sender, EventArgs e)
        {
            var Remove_Cabbage = Convert.ToInt32(Cabbage_txt.Text);
            if (Remove_Cabbage == 0)
            {
                MessageBox.Show("Oops there are no Cabbage's left");

            }
            else
            {
                Remove_Cabbage = Remove_Cabbage - 1;
                Cabbage_txt.Text = Remove_Cabbage.ToString();
            }
        }

        private void Add_Pumpkin_Click(object sender, EventArgs e)
        {
            var add_Pumpkin = Convert.ToInt32(Pumpkin_txt.Text);
            add_Pumpkin++;
            Pumpkin_txt.Text = add_Pumpkin.ToString();
        }

        private void Remove_Pumpkin_Click(object sender, EventArgs e)
        {
            var Remove_Pumpkin = Convert.ToInt32(Pumpkin_txt.Text);
            if (Remove_Pumpkin == 0)
            {
                MessageBox.Show("Oops there are no Pumpkin's left");

            }
            else
            {
                Remove_Pumpkin = Remove_Pumpkin - 1;
                Pumpkin_txt.Text = Remove_Pumpkin.ToString();
            }
        }

        private void Add_Lettuce_Click(object sender, EventArgs e)
        {
            var add_Lettuce = Convert.ToInt32(Lettuce_txt.Text);
            add_Lettuce++;
            Lettuce_txt.Text = add_Lettuce.ToString();
        }

        private void Remove_Lettuce_Click(object sender, EventArgs e)
        {
            var Remove_Lettuce = Convert.ToInt32(Lettuce_txt.Text);
            if (Remove_Lettuce == 0)
            {
                MessageBox.Show("Oops there are no Lettuce's left");

            }
            else
            {
                Remove_Lettuce = Remove_Lettuce - 1;
                Lettuce_txt.Text = Remove_Lettuce.ToString();
            }
        }

        private void Reset_Inventory_Click(object sender, EventArgs e)
        {
            {
                Action<Control.ControlCollection> function = null;
                function = (controls) =>
                {
                    foreach (Control control in controls)
                        if (control is TextBox)
                            (control as TextBox).Text = "0";
                        else
                            function(control.Controls);
                };
                function(Controls);
            }
        }


        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
