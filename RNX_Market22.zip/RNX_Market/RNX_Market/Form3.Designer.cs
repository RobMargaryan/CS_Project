﻿namespace RNX_Market
{
    partial class Inventory_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inventory_form));
            this.Apple_txt = new System.Windows.Forms.TextBox();
            this.Banana_txt = new System.Windows.Forms.TextBox();
            this.Kiwi_txt = new System.Windows.Forms.TextBox();
            this.Peach_txt = new System.Windows.Forms.TextBox();
            this.Pineapple_txt = new System.Windows.Forms.TextBox();
            this.Orange_txt = new System.Windows.Forms.TextBox();
            this.Pear_txt = new System.Windows.Forms.TextBox();
            this.Mandarin_txt = new System.Windows.Forms.TextBox();
            this.Strawberry_txt = new System.Windows.Forms.TextBox();
            this.Grape_txt = new System.Windows.Forms.TextBox();
            this.Mango_txt = new System.Windows.Forms.TextBox();
            this.Cherry_txt = new System.Windows.Forms.TextBox();
            this.Pumpkin_txt = new System.Windows.Forms.TextBox();
            this.Cabbage_txt = new System.Windows.Forms.TextBox();
            this.Celery_txt = new System.Windows.Forms.TextBox();
            this.Bean_txt = new System.Windows.Forms.TextBox();
            this.Soy_txt = new System.Windows.Forms.TextBox();
            this.Broccoli_txt = new System.Windows.Forms.TextBox();
            this.Lettuce_txt = new System.Windows.Forms.TextBox();
            this.Cucumber_txt = new System.Windows.Forms.TextBox();
            this.Tomato_txt = new System.Windows.Forms.TextBox();
            this.Corn_txt = new System.Windows.Forms.TextBox();
            this.Carrot_txt = new System.Windows.Forms.TextBox();
            this.Potato_txt = new System.Windows.Forms.TextBox();
            this.Inventory = new System.Windows.Forms.Label();
            this.Back_Inventory = new System.Windows.Forms.Button();
            this.Add_Apple = new System.Windows.Forms.Button();
            this.Remove_Apple = new System.Windows.Forms.Button();
            this.Add_Banana = new System.Windows.Forms.Button();
            this.Remove_Banana = new System.Windows.Forms.Button();
            this.Remove_Orange = new System.Windows.Forms.Button();
            this.Remove_Kiwi = new System.Windows.Forms.Button();
            this.Remove_Peach = new System.Windows.Forms.Button();
            this.Remove_Pineapple = new System.Windows.Forms.Button();
            this.Remove_Pear = new System.Windows.Forms.Button();
            this.Remove_Mandarin = new System.Windows.Forms.Button();
            this.Remove_Strawberry = new System.Windows.Forms.Button();
            this.Remove_Grape = new System.Windows.Forms.Button();
            this.Remove_Mango = new System.Windows.Forms.Button();
            this.Remove_Cherry = new System.Windows.Forms.Button();
            this.Add_Pear = new System.Windows.Forms.Button();
            this.Add_Mandarin = new System.Windows.Forms.Button();
            this.Add_Strawberry = new System.Windows.Forms.Button();
            this.Add_Grape = new System.Windows.Forms.Button();
            this.Add_Mango = new System.Windows.Forms.Button();
            this.Add_Cherry = new System.Windows.Forms.Button();
            this.Add_Lettuce = new System.Windows.Forms.Button();
            this.Add_Cucumber = new System.Windows.Forms.Button();
            this.Add_Tomato = new System.Windows.Forms.Button();
            this.Add_Corn = new System.Windows.Forms.Button();
            this.Add_Carrot = new System.Windows.Forms.Button();
            this.Add_Potato = new System.Windows.Forms.Button();
            this.Remove_Lettuce = new System.Windows.Forms.Button();
            this.Remove_Cucumber = new System.Windows.Forms.Button();
            this.Remove_Tomato = new System.Windows.Forms.Button();
            this.Remove_Corn = new System.Windows.Forms.Button();
            this.Remove_Carrot = new System.Windows.Forms.Button();
            this.Remove_Potato = new System.Windows.Forms.Button();
            this.Remove_Pumpkin = new System.Windows.Forms.Button();
            this.Remove_Cabbage = new System.Windows.Forms.Button();
            this.Remove_Celery = new System.Windows.Forms.Button();
            this.Remove_Bean = new System.Windows.Forms.Button();
            this.Remove_Soy = new System.Windows.Forms.Button();
            this.Remove_Broccoli = new System.Windows.Forms.Button();
            this.Add_Pumpkin = new System.Windows.Forms.Button();
            this.Add_Cabbage = new System.Windows.Forms.Button();
            this.Add_Celery = new System.Windows.Forms.Button();
            this.Add_Bean = new System.Windows.Forms.Button();
            this.Add_Soy = new System.Windows.Forms.Button();
            this.Add_Broccoli = new System.Windows.Forms.Button();
            this.Add_Kiwi = new System.Windows.Forms.Button();
            this.Add_Orange = new System.Windows.Forms.Button();
            this.Add_Pineapple = new System.Windows.Forms.Button();
            this.Add_Peach = new System.Windows.Forms.Button();
            this.Apple_Inv_Lab = new System.Windows.Forms.Label();
            this.Banana_Inv_Lab = new System.Windows.Forms.Label();
            this.Kiwi = new System.Windows.Forms.Label();
            this.Orange = new System.Windows.Forms.Label();
            this.Pineapple = new System.Windows.Forms.Label();
            this.Peach = new System.Windows.Forms.Label();
            this.Pear = new System.Windows.Forms.Label();
            this.Mandarin = new System.Windows.Forms.Label();
            this.Strawberry = new System.Windows.Forms.Label();
            this.Grape = new System.Windows.Forms.Label();
            this.Mango = new System.Windows.Forms.Label();
            this.Cherry = new System.Windows.Forms.Label();
            this.Pumpkin = new System.Windows.Forms.Label();
            this.Cabbage = new System.Windows.Forms.Label();
            this.Celery = new System.Windows.Forms.Label();
            this.Bean = new System.Windows.Forms.Label();
            this.Soy = new System.Windows.Forms.Label();
            this.Broccoli = new System.Windows.Forms.Label();
            this.Lettuce = new System.Windows.Forms.Label();
            this.Cucumber = new System.Windows.Forms.Label();
            this.Tomato = new System.Windows.Forms.Label();
            this.Corn = new System.Windows.Forms.Label();
            this.Carrot = new System.Windows.Forms.Label();
            this.Potato = new System.Windows.Forms.Label();
            this.Reset_Inventory = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Apple_txt
            // 
            this.Apple_txt.Location = new System.Drawing.Point(562, 240);
            this.Apple_txt.Multiline = true;
            this.Apple_txt.Name = "Apple_txt";
            this.Apple_txt.Size = new System.Drawing.Size(47, 47);
            this.Apple_txt.TabIndex = 12;
            this.Apple_txt.Text = "0";
            this.Apple_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Apple_txt_KeyPress);
            // 
            // Banana_txt
            // 
            this.Banana_txt.Location = new System.Drawing.Point(562, 410);
            this.Banana_txt.Multiline = true;
            this.Banana_txt.Name = "Banana_txt";
            this.Banana_txt.Size = new System.Drawing.Size(47, 47);
            this.Banana_txt.TabIndex = 13;
            this.Banana_txt.Text = "0";
            this.Banana_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Banana_txt_KeyPress);
            // 
            // Kiwi_txt
            // 
            this.Kiwi_txt.Location = new System.Drawing.Point(562, 580);
            this.Kiwi_txt.Multiline = true;
            this.Kiwi_txt.Name = "Kiwi_txt";
            this.Kiwi_txt.Size = new System.Drawing.Size(47, 47);
            this.Kiwi_txt.TabIndex = 14;
            this.Kiwi_txt.Text = "0";
            this.Kiwi_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Kiwi_txt_KeyPress);
            // 
            // Peach_txt
            // 
            this.Peach_txt.Location = new System.Drawing.Point(562, 1090);
            this.Peach_txt.Multiline = true;
            this.Peach_txt.Name = "Peach_txt";
            this.Peach_txt.Size = new System.Drawing.Size(47, 47);
            this.Peach_txt.TabIndex = 17;
            this.Peach_txt.Text = "0";
            this.Peach_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Peach_txt_KeyPress);
            // 
            // Pineapple_txt
            // 
            this.Pineapple_txt.Location = new System.Drawing.Point(562, 920);
            this.Pineapple_txt.Multiline = true;
            this.Pineapple_txt.Name = "Pineapple_txt";
            this.Pineapple_txt.Size = new System.Drawing.Size(47, 47);
            this.Pineapple_txt.TabIndex = 16;
            this.Pineapple_txt.Text = "0";
            this.Pineapple_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Pineapple_txt_KeyPress);
            // 
            // Orange_txt
            // 
            this.Orange_txt.Location = new System.Drawing.Point(562, 750);
            this.Orange_txt.Multiline = true;
            this.Orange_txt.Name = "Orange_txt";
            this.Orange_txt.Size = new System.Drawing.Size(47, 47);
            this.Orange_txt.TabIndex = 15;
            this.Orange_txt.Text = "0";
            this.Orange_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Orange_txt_KeyPress);
            // 
            // Pear_txt
            // 
            this.Pear_txt.Location = new System.Drawing.Point(1120, 1090);
            this.Pear_txt.Multiline = true;
            this.Pear_txt.Name = "Pear_txt";
            this.Pear_txt.Size = new System.Drawing.Size(47, 47);
            this.Pear_txt.TabIndex = 23;
            this.Pear_txt.Text = "0";
            this.Pear_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Pear_txt_KeyPress);
            // 
            // Mandarin_txt
            // 
            this.Mandarin_txt.Location = new System.Drawing.Point(1120, 920);
            this.Mandarin_txt.Multiline = true;
            this.Mandarin_txt.Name = "Mandarin_txt";
            this.Mandarin_txt.Size = new System.Drawing.Size(47, 47);
            this.Mandarin_txt.TabIndex = 22;
            this.Mandarin_txt.Text = "0";
            // 
            // Strawberry_txt
            // 
            this.Strawberry_txt.Location = new System.Drawing.Point(1120, 750);
            this.Strawberry_txt.Multiline = true;
            this.Strawberry_txt.Name = "Strawberry_txt";
            this.Strawberry_txt.Size = new System.Drawing.Size(47, 47);
            this.Strawberry_txt.TabIndex = 21;
            this.Strawberry_txt.Text = "0";
            this.Strawberry_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Strawberry_txt_KeyPress);
            // 
            // Grape_txt
            // 
            this.Grape_txt.Location = new System.Drawing.Point(1120, 580);
            this.Grape_txt.Multiline = true;
            this.Grape_txt.Name = "Grape_txt";
            this.Grape_txt.Size = new System.Drawing.Size(47, 47);
            this.Grape_txt.TabIndex = 20;
            this.Grape_txt.Text = "0";
            this.Grape_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Grape_txt_KeyPress);
            // 
            // Mango_txt
            // 
            this.Mango_txt.Location = new System.Drawing.Point(1120, 410);
            this.Mango_txt.Multiline = true;
            this.Mango_txt.Name = "Mango_txt";
            this.Mango_txt.Size = new System.Drawing.Size(47, 47);
            this.Mango_txt.TabIndex = 19;
            this.Mango_txt.Text = "0";
            this.Mango_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Mango_txt_KeyPress);
            // 
            // Cherry_txt
            // 
            this.Cherry_txt.Location = new System.Drawing.Point(1120, 240);
            this.Cherry_txt.Multiline = true;
            this.Cherry_txt.Name = "Cherry_txt";
            this.Cherry_txt.Size = new System.Drawing.Size(47, 47);
            this.Cherry_txt.TabIndex = 18;
            this.Cherry_txt.Text = "0";
            this.Cherry_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Cherry_txt_KeyPress);
            // 
            // Pumpkin_txt
            // 
            this.Pumpkin_txt.Location = new System.Drawing.Point(2211, 1080);
            this.Pumpkin_txt.Multiline = true;
            this.Pumpkin_txt.Name = "Pumpkin_txt";
            this.Pumpkin_txt.Size = new System.Drawing.Size(47, 47);
            this.Pumpkin_txt.TabIndex = 47;
            this.Pumpkin_txt.Text = "0";
            this.Pumpkin_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Pumpkin_txt_KeyPress);
            // 
            // Cabbage_txt
            // 
            this.Cabbage_txt.Location = new System.Drawing.Point(2211, 920);
            this.Cabbage_txt.Multiline = true;
            this.Cabbage_txt.Name = "Cabbage_txt";
            this.Cabbage_txt.Size = new System.Drawing.Size(47, 47);
            this.Cabbage_txt.TabIndex = 46;
            this.Cabbage_txt.Text = "0";
            this.Cabbage_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Cabbage_txt_KeyPress);
            // 
            // Celery_txt
            // 
            this.Celery_txt.Location = new System.Drawing.Point(2211, 749);
            this.Celery_txt.Multiline = true;
            this.Celery_txt.Name = "Celery_txt";
            this.Celery_txt.Size = new System.Drawing.Size(47, 47);
            this.Celery_txt.TabIndex = 45;
            this.Celery_txt.Text = "0";
            this.Celery_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Celery_txt_KeyPress);
            // 
            // Bean_txt
            // 
            this.Bean_txt.Location = new System.Drawing.Point(2211, 586);
            this.Bean_txt.Multiline = true;
            this.Bean_txt.Name = "Bean_txt";
            this.Bean_txt.Size = new System.Drawing.Size(47, 47);
            this.Bean_txt.TabIndex = 44;
            this.Bean_txt.Text = "0";
            this.Bean_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Bean_txt_KeyPress);
            // 
            // Soy_txt
            // 
            this.Soy_txt.Location = new System.Drawing.Point(2211, 410);
            this.Soy_txt.Multiline = true;
            this.Soy_txt.Name = "Soy_txt";
            this.Soy_txt.Size = new System.Drawing.Size(47, 47);
            this.Soy_txt.TabIndex = 43;
            this.Soy_txt.Text = "0";
            this.Soy_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Soy_txt_KeyPress);
            // 
            // Broccoli_txt
            // 
            this.Broccoli_txt.Location = new System.Drawing.Point(2211, 240);
            this.Broccoli_txt.Multiline = true;
            this.Broccoli_txt.Name = "Broccoli_txt";
            this.Broccoli_txt.Size = new System.Drawing.Size(47, 47);
            this.Broccoli_txt.TabIndex = 42;
            this.Broccoli_txt.Text = "0";
            this.Broccoli_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Broccoli_txt_KeyPress);
            // 
            // Lettuce_txt
            // 
            this.Lettuce_txt.Location = new System.Drawing.Point(1671, 1080);
            this.Lettuce_txt.Multiline = true;
            this.Lettuce_txt.Name = "Lettuce_txt";
            this.Lettuce_txt.Size = new System.Drawing.Size(47, 47);
            this.Lettuce_txt.TabIndex = 41;
            this.Lettuce_txt.Text = "0";
            this.Lettuce_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Lettuce_txt_KeyPress);
            // 
            // Cucumber_txt
            // 
            this.Cucumber_txt.Location = new System.Drawing.Point(1671, 920);
            this.Cucumber_txt.Multiline = true;
            this.Cucumber_txt.Name = "Cucumber_txt";
            this.Cucumber_txt.Size = new System.Drawing.Size(47, 47);
            this.Cucumber_txt.TabIndex = 40;
            this.Cucumber_txt.Text = "0";
            this.Cucumber_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Cucumber_txt_KeyPress);
            // 
            // Tomato_txt
            // 
            this.Tomato_txt.Location = new System.Drawing.Point(1671, 750);
            this.Tomato_txt.Multiline = true;
            this.Tomato_txt.Name = "Tomato_txt";
            this.Tomato_txt.Size = new System.Drawing.Size(47, 47);
            this.Tomato_txt.TabIndex = 39;
            this.Tomato_txt.Text = "0";
            this.Tomato_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Tomato_txt_KeyPress);
            // 
            // Corn_txt
            // 
            this.Corn_txt.Location = new System.Drawing.Point(1671, 580);
            this.Corn_txt.Multiline = true;
            this.Corn_txt.Name = "Corn_txt";
            this.Corn_txt.Size = new System.Drawing.Size(47, 47);
            this.Corn_txt.TabIndex = 38;
            this.Corn_txt.Text = "0";
            this.Corn_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Corn_txt_KeyPress);
            // 
            // Carrot_txt
            // 
            this.Carrot_txt.Location = new System.Drawing.Point(1671, 410);
            this.Carrot_txt.Multiline = true;
            this.Carrot_txt.Name = "Carrot_txt";
            this.Carrot_txt.Size = new System.Drawing.Size(47, 47);
            this.Carrot_txt.TabIndex = 37;
            this.Carrot_txt.Text = "0";
            this.Carrot_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Carrot_txt_KeyPress);
            // 
            // Potato_txt
            // 
            this.Potato_txt.Location = new System.Drawing.Point(1671, 240);
            this.Potato_txt.Multiline = true;
            this.Potato_txt.Name = "Potato_txt";
            this.Potato_txt.Size = new System.Drawing.Size(47, 47);
            this.Potato_txt.TabIndex = 36;
            this.Potato_txt.Text = "0";
            this.Potato_txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Potato_txt_KeyPress);
            // 
            // Inventory
            // 
            this.Inventory.AutoSize = true;
            this.Inventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Inventory.Location = new System.Drawing.Point(1292, 57);
            this.Inventory.Name = "Inventory";
            this.Inventory.Size = new System.Drawing.Size(254, 61);
            this.Inventory.TabIndex = 48;
            this.Inventory.Text = "Inventory";
            // 
            // Back_Inventory
            // 
            this.Back_Inventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Back_Inventory.Location = new System.Drawing.Point(185, 1241);
            this.Back_Inventory.Name = "Back_Inventory";
            this.Back_Inventory.Size = new System.Drawing.Size(248, 63);
            this.Back_Inventory.TabIndex = 49;
            this.Back_Inventory.Text = "Back ";
            this.Back_Inventory.UseVisualStyleBackColor = true;
            this.Back_Inventory.Click += new System.EventHandler(this.Back_Inventory_Click);
            // 
            // Add_Apple
            // 
            this.Add_Apple.Location = new System.Drawing.Point(400, 220);
            this.Add_Apple.Name = "Add_Apple";
            this.Add_Apple.Size = new System.Drawing.Size(122, 83);
            this.Add_Apple.TabIndex = 50;
            this.Add_Apple.Text = "Add";
            this.Add_Apple.UseVisualStyleBackColor = true;
            this.Add_Apple.Click += new System.EventHandler(this.Add_Apple_Click);
            // 
            // Remove_Apple
            // 
            this.Remove_Apple.Location = new System.Drawing.Point(660, 220);
            this.Remove_Apple.Name = "Remove_Apple";
            this.Remove_Apple.Size = new System.Drawing.Size(122, 83);
            this.Remove_Apple.TabIndex = 51;
            this.Remove_Apple.Text = "Remove";
            this.Remove_Apple.UseVisualStyleBackColor = true;
            this.Remove_Apple.Click += new System.EventHandler(this.Remove_Apple_Click);
            // 
            // Add_Banana
            // 
            this.Add_Banana.Location = new System.Drawing.Point(400, 390);
            this.Add_Banana.Name = "Add_Banana";
            this.Add_Banana.Size = new System.Drawing.Size(122, 83);
            this.Add_Banana.TabIndex = 52;
            this.Add_Banana.Text = "Add";
            this.Add_Banana.UseVisualStyleBackColor = true;
            this.Add_Banana.Click += new System.EventHandler(this.Add_Banana_Click);
            // 
            // Remove_Banana
            // 
            this.Remove_Banana.Location = new System.Drawing.Point(660, 390);
            this.Remove_Banana.Name = "Remove_Banana";
            this.Remove_Banana.Size = new System.Drawing.Size(122, 83);
            this.Remove_Banana.TabIndex = 53;
            this.Remove_Banana.Text = "Remove";
            this.Remove_Banana.UseVisualStyleBackColor = true;
            this.Remove_Banana.Click += new System.EventHandler(this.Remove_Banana_Click);
            // 
            // Remove_Orange
            // 
            this.Remove_Orange.Location = new System.Drawing.Point(660, 730);
            this.Remove_Orange.Name = "Remove_Orange";
            this.Remove_Orange.Size = new System.Drawing.Size(122, 83);
            this.Remove_Orange.TabIndex = 55;
            this.Remove_Orange.Text = "Remove";
            this.Remove_Orange.UseVisualStyleBackColor = true;
            this.Remove_Orange.Click += new System.EventHandler(this.Remove_Orange_Click);
            // 
            // Remove_Kiwi
            // 
            this.Remove_Kiwi.Location = new System.Drawing.Point(660, 560);
            this.Remove_Kiwi.Name = "Remove_Kiwi";
            this.Remove_Kiwi.Size = new System.Drawing.Size(122, 83);
            this.Remove_Kiwi.TabIndex = 54;
            this.Remove_Kiwi.Text = "Remove";
            this.Remove_Kiwi.UseVisualStyleBackColor = true;
            this.Remove_Kiwi.Click += new System.EventHandler(this.Remove_Kiwi_Click);
            // 
            // Remove_Peach
            // 
            this.Remove_Peach.Location = new System.Drawing.Point(660, 1070);
            this.Remove_Peach.Name = "Remove_Peach";
            this.Remove_Peach.Size = new System.Drawing.Size(122, 83);
            this.Remove_Peach.TabIndex = 57;
            this.Remove_Peach.Text = "Remove";
            this.Remove_Peach.UseVisualStyleBackColor = true;
            this.Remove_Peach.Click += new System.EventHandler(this.Remove_Peach_Click);
            // 
            // Remove_Pineapple
            // 
            this.Remove_Pineapple.Location = new System.Drawing.Point(660, 900);
            this.Remove_Pineapple.Name = "Remove_Pineapple";
            this.Remove_Pineapple.Size = new System.Drawing.Size(122, 83);
            this.Remove_Pineapple.TabIndex = 56;
            this.Remove_Pineapple.Text = "Remove";
            this.Remove_Pineapple.UseVisualStyleBackColor = true;
            this.Remove_Pineapple.Click += new System.EventHandler(this.Remove_Pineapple_Click);
            // 
            // Remove_Pear
            // 
            this.Remove_Pear.Location = new System.Drawing.Point(1210, 1070);
            this.Remove_Pear.Name = "Remove_Pear";
            this.Remove_Pear.Size = new System.Drawing.Size(122, 83);
            this.Remove_Pear.TabIndex = 63;
            this.Remove_Pear.Text = "Remove";
            this.Remove_Pear.UseVisualStyleBackColor = true;
            this.Remove_Pear.Click += new System.EventHandler(this.Remove_Pear_Click);
            // 
            // Remove_Mandarin
            // 
            this.Remove_Mandarin.Location = new System.Drawing.Point(1210, 900);
            this.Remove_Mandarin.Name = "Remove_Mandarin";
            this.Remove_Mandarin.Size = new System.Drawing.Size(122, 83);
            this.Remove_Mandarin.TabIndex = 62;
            this.Remove_Mandarin.Text = "Remove";
            this.Remove_Mandarin.UseVisualStyleBackColor = true;
            this.Remove_Mandarin.Click += new System.EventHandler(this.Remove_Mandarin_Click);
            // 
            // Remove_Strawberry
            // 
            this.Remove_Strawberry.Location = new System.Drawing.Point(1210, 730);
            this.Remove_Strawberry.Name = "Remove_Strawberry";
            this.Remove_Strawberry.Size = new System.Drawing.Size(122, 83);
            this.Remove_Strawberry.TabIndex = 61;
            this.Remove_Strawberry.Text = "Remove";
            this.Remove_Strawberry.UseVisualStyleBackColor = true;
            this.Remove_Strawberry.Click += new System.EventHandler(this.Remove_Strawberry_Click);
            // 
            // Remove_Grape
            // 
            this.Remove_Grape.Location = new System.Drawing.Point(1210, 560);
            this.Remove_Grape.Name = "Remove_Grape";
            this.Remove_Grape.Size = new System.Drawing.Size(122, 83);
            this.Remove_Grape.TabIndex = 60;
            this.Remove_Grape.Text = "Remove";
            this.Remove_Grape.UseVisualStyleBackColor = true;
            this.Remove_Grape.Click += new System.EventHandler(this.Remove_Grape_Click);
            // 
            // Remove_Mango
            // 
            this.Remove_Mango.Location = new System.Drawing.Point(1210, 390);
            this.Remove_Mango.Name = "Remove_Mango";
            this.Remove_Mango.Size = new System.Drawing.Size(122, 83);
            this.Remove_Mango.TabIndex = 59;
            this.Remove_Mango.Text = "Remove";
            this.Remove_Mango.UseVisualStyleBackColor = true;
            this.Remove_Mango.Click += new System.EventHandler(this.Remove_Mango_Click);
            // 
            // Remove_Cherry
            // 
            this.Remove_Cherry.Location = new System.Drawing.Point(1210, 220);
            this.Remove_Cherry.Name = "Remove_Cherry";
            this.Remove_Cherry.Size = new System.Drawing.Size(122, 83);
            this.Remove_Cherry.TabIndex = 58;
            this.Remove_Cherry.Text = "Remove";
            this.Remove_Cherry.UseVisualStyleBackColor = true;
            this.Remove_Cherry.Click += new System.EventHandler(this.Remove_Cherry_Click);
            // 
            // Add_Pear
            // 
            this.Add_Pear.Location = new System.Drawing.Point(950, 1070);
            this.Add_Pear.Name = "Add_Pear";
            this.Add_Pear.Size = new System.Drawing.Size(122, 83);
            this.Add_Pear.TabIndex = 69;
            this.Add_Pear.Text = "Add";
            this.Add_Pear.UseVisualStyleBackColor = true;
            this.Add_Pear.Click += new System.EventHandler(this.Add_Pear_Click);
            // 
            // Add_Mandarin
            // 
            this.Add_Mandarin.Location = new System.Drawing.Point(950, 900);
            this.Add_Mandarin.Name = "Add_Mandarin";
            this.Add_Mandarin.Size = new System.Drawing.Size(122, 83);
            this.Add_Mandarin.TabIndex = 68;
            this.Add_Mandarin.Text = "Add";
            this.Add_Mandarin.UseVisualStyleBackColor = true;
            this.Add_Mandarin.Click += new System.EventHandler(this.Add_Mandarin_Click);
            // 
            // Add_Strawberry
            // 
            this.Add_Strawberry.Location = new System.Drawing.Point(950, 730);
            this.Add_Strawberry.Name = "Add_Strawberry";
            this.Add_Strawberry.Size = new System.Drawing.Size(122, 83);
            this.Add_Strawberry.TabIndex = 67;
            this.Add_Strawberry.Text = "Add";
            this.Add_Strawberry.UseVisualStyleBackColor = true;
            this.Add_Strawberry.Click += new System.EventHandler(this.Add_Strawberry_Click);
            // 
            // Add_Grape
            // 
            this.Add_Grape.Location = new System.Drawing.Point(950, 560);
            this.Add_Grape.Name = "Add_Grape";
            this.Add_Grape.Size = new System.Drawing.Size(122, 83);
            this.Add_Grape.TabIndex = 66;
            this.Add_Grape.Text = "Add";
            this.Add_Grape.UseVisualStyleBackColor = true;
            this.Add_Grape.Click += new System.EventHandler(this.Add_Grape_Click);
            // 
            // Add_Mango
            // 
            this.Add_Mango.Location = new System.Drawing.Point(950, 390);
            this.Add_Mango.Name = "Add_Mango";
            this.Add_Mango.Size = new System.Drawing.Size(122, 83);
            this.Add_Mango.TabIndex = 65;
            this.Add_Mango.Text = "Add";
            this.Add_Mango.UseVisualStyleBackColor = true;
            this.Add_Mango.Click += new System.EventHandler(this.Add_Mango_Click);
            // 
            // Add_Cherry
            // 
            this.Add_Cherry.Location = new System.Drawing.Point(950, 220);
            this.Add_Cherry.Name = "Add_Cherry";
            this.Add_Cherry.Size = new System.Drawing.Size(122, 83);
            this.Add_Cherry.TabIndex = 64;
            this.Add_Cherry.Text = "Add";
            this.Add_Cherry.UseVisualStyleBackColor = true;
            this.Add_Cherry.Click += new System.EventHandler(this.Add_Cherry_Click);
            // 
            // Add_Lettuce
            // 
            this.Add_Lettuce.Location = new System.Drawing.Point(1500, 1070);
            this.Add_Lettuce.Name = "Add_Lettuce";
            this.Add_Lettuce.Size = new System.Drawing.Size(122, 83);
            this.Add_Lettuce.TabIndex = 75;
            this.Add_Lettuce.Text = "Add";
            this.Add_Lettuce.UseVisualStyleBackColor = true;
            this.Add_Lettuce.Click += new System.EventHandler(this.Add_Lettuce_Click);
            // 
            // Add_Cucumber
            // 
            this.Add_Cucumber.Location = new System.Drawing.Point(1500, 900);
            this.Add_Cucumber.Name = "Add_Cucumber";
            this.Add_Cucumber.Size = new System.Drawing.Size(122, 83);
            this.Add_Cucumber.TabIndex = 74;
            this.Add_Cucumber.Text = "Add";
            this.Add_Cucumber.UseVisualStyleBackColor = true;
            this.Add_Cucumber.Click += new System.EventHandler(this.Add_Cucumber_Click);
            // 
            // Add_Tomato
            // 
            this.Add_Tomato.Location = new System.Drawing.Point(1500, 730);
            this.Add_Tomato.Name = "Add_Tomato";
            this.Add_Tomato.Size = new System.Drawing.Size(122, 83);
            this.Add_Tomato.TabIndex = 73;
            this.Add_Tomato.Text = "Add";
            this.Add_Tomato.UseVisualStyleBackColor = true;
            this.Add_Tomato.Click += new System.EventHandler(this.Add_Tomato_Click);
            // 
            // Add_Corn
            // 
            this.Add_Corn.Location = new System.Drawing.Point(1500, 560);
            this.Add_Corn.Name = "Add_Corn";
            this.Add_Corn.Size = new System.Drawing.Size(122, 83);
            this.Add_Corn.TabIndex = 72;
            this.Add_Corn.Text = "Add";
            this.Add_Corn.UseVisualStyleBackColor = true;
            this.Add_Corn.Click += new System.EventHandler(this.Add_Corn_Click);
            // 
            // Add_Carrot
            // 
            this.Add_Carrot.Location = new System.Drawing.Point(1500, 390);
            this.Add_Carrot.Name = "Add_Carrot";
            this.Add_Carrot.Size = new System.Drawing.Size(122, 83);
            this.Add_Carrot.TabIndex = 71;
            this.Add_Carrot.Text = "Add";
            this.Add_Carrot.UseVisualStyleBackColor = true;
            this.Add_Carrot.Click += new System.EventHandler(this.Add_Carrot_Click);
            // 
            // Add_Potato
            // 
            this.Add_Potato.Location = new System.Drawing.Point(1500, 220);
            this.Add_Potato.Name = "Add_Potato";
            this.Add_Potato.Size = new System.Drawing.Size(122, 83);
            this.Add_Potato.TabIndex = 70;
            this.Add_Potato.Text = "Add";
            this.Add_Potato.UseVisualStyleBackColor = true;
            this.Add_Potato.Click += new System.EventHandler(this.Add_Potato_Click);
            // 
            // Remove_Lettuce
            // 
            this.Remove_Lettuce.Location = new System.Drawing.Point(1760, 1070);
            this.Remove_Lettuce.Name = "Remove_Lettuce";
            this.Remove_Lettuce.Size = new System.Drawing.Size(122, 83);
            this.Remove_Lettuce.TabIndex = 81;
            this.Remove_Lettuce.Text = "Remove";
            this.Remove_Lettuce.UseVisualStyleBackColor = true;
            this.Remove_Lettuce.Click += new System.EventHandler(this.Remove_Lettuce_Click);
            // 
            // Remove_Cucumber
            // 
            this.Remove_Cucumber.Location = new System.Drawing.Point(1760, 900);
            this.Remove_Cucumber.Name = "Remove_Cucumber";
            this.Remove_Cucumber.Size = new System.Drawing.Size(122, 83);
            this.Remove_Cucumber.TabIndex = 80;
            this.Remove_Cucumber.Text = "Remove";
            this.Remove_Cucumber.UseVisualStyleBackColor = true;
            this.Remove_Cucumber.Click += new System.EventHandler(this.Remove_Cucumber_Click);
            // 
            // Remove_Tomato
            // 
            this.Remove_Tomato.Location = new System.Drawing.Point(1760, 730);
            this.Remove_Tomato.Name = "Remove_Tomato";
            this.Remove_Tomato.Size = new System.Drawing.Size(122, 83);
            this.Remove_Tomato.TabIndex = 79;
            this.Remove_Tomato.Text = "Remove";
            this.Remove_Tomato.UseVisualStyleBackColor = true;
            this.Remove_Tomato.Click += new System.EventHandler(this.Remove_Tomato_Click);
            // 
            // Remove_Corn
            // 
            this.Remove_Corn.Location = new System.Drawing.Point(1760, 560);
            this.Remove_Corn.Name = "Remove_Corn";
            this.Remove_Corn.Size = new System.Drawing.Size(122, 83);
            this.Remove_Corn.TabIndex = 78;
            this.Remove_Corn.Text = "Remove";
            this.Remove_Corn.UseVisualStyleBackColor = true;
            this.Remove_Corn.Click += new System.EventHandler(this.Remove_Corn_Click);
            // 
            // Remove_Carrot
            // 
            this.Remove_Carrot.Location = new System.Drawing.Point(1760, 390);
            this.Remove_Carrot.Name = "Remove_Carrot";
            this.Remove_Carrot.Size = new System.Drawing.Size(122, 83);
            this.Remove_Carrot.TabIndex = 77;
            this.Remove_Carrot.Text = "Remove";
            this.Remove_Carrot.UseVisualStyleBackColor = true;
            this.Remove_Carrot.Click += new System.EventHandler(this.Remove_Carrot_Click);
            // 
            // Remove_Potato
            // 
            this.Remove_Potato.Location = new System.Drawing.Point(1760, 220);
            this.Remove_Potato.Name = "Remove_Potato";
            this.Remove_Potato.Size = new System.Drawing.Size(122, 83);
            this.Remove_Potato.TabIndex = 76;
            this.Remove_Potato.Text = "Remove";
            this.Remove_Potato.UseVisualStyleBackColor = true;
            this.Remove_Potato.Click += new System.EventHandler(this.Remove_Potato_Click);
            // 
            // Remove_Pumpkin
            // 
            this.Remove_Pumpkin.Location = new System.Drawing.Point(2310, 1070);
            this.Remove_Pumpkin.Name = "Remove_Pumpkin";
            this.Remove_Pumpkin.Size = new System.Drawing.Size(122, 83);
            this.Remove_Pumpkin.TabIndex = 87;
            this.Remove_Pumpkin.Text = "Remove";
            this.Remove_Pumpkin.UseVisualStyleBackColor = true;
            this.Remove_Pumpkin.Click += new System.EventHandler(this.Remove_Pumpkin_Click);
            // 
            // Remove_Cabbage
            // 
            this.Remove_Cabbage.Location = new System.Drawing.Point(2310, 900);
            this.Remove_Cabbage.Name = "Remove_Cabbage";
            this.Remove_Cabbage.Size = new System.Drawing.Size(122, 83);
            this.Remove_Cabbage.TabIndex = 86;
            this.Remove_Cabbage.Text = "Remove";
            this.Remove_Cabbage.UseVisualStyleBackColor = true;
            this.Remove_Cabbage.Click += new System.EventHandler(this.Remove_Cabbage_Click);
            // 
            // Remove_Celery
            // 
            this.Remove_Celery.Location = new System.Drawing.Point(2310, 730);
            this.Remove_Celery.Name = "Remove_Celery";
            this.Remove_Celery.Size = new System.Drawing.Size(122, 83);
            this.Remove_Celery.TabIndex = 85;
            this.Remove_Celery.Text = "Remove";
            this.Remove_Celery.UseVisualStyleBackColor = true;
            this.Remove_Celery.Click += new System.EventHandler(this.Remove_Celery_Click);
            // 
            // Remove_Bean
            // 
            this.Remove_Bean.Location = new System.Drawing.Point(2310, 560);
            this.Remove_Bean.Name = "Remove_Bean";
            this.Remove_Bean.Size = new System.Drawing.Size(122, 83);
            this.Remove_Bean.TabIndex = 84;
            this.Remove_Bean.Text = "Remove";
            this.Remove_Bean.UseVisualStyleBackColor = true;
            this.Remove_Bean.Click += new System.EventHandler(this.Remove_Bean_Click);
            // 
            // Remove_Soy
            // 
            this.Remove_Soy.Location = new System.Drawing.Point(2310, 390);
            this.Remove_Soy.Name = "Remove_Soy";
            this.Remove_Soy.Size = new System.Drawing.Size(122, 83);
            this.Remove_Soy.TabIndex = 83;
            this.Remove_Soy.Text = "Remove";
            this.Remove_Soy.UseVisualStyleBackColor = true;
            this.Remove_Soy.Click += new System.EventHandler(this.Remove_Soy_Click);
            // 
            // Remove_Broccoli
            // 
            this.Remove_Broccoli.Location = new System.Drawing.Point(2310, 220);
            this.Remove_Broccoli.Name = "Remove_Broccoli";
            this.Remove_Broccoli.Size = new System.Drawing.Size(122, 83);
            this.Remove_Broccoli.TabIndex = 82;
            this.Remove_Broccoli.Text = "Remove";
            this.Remove_Broccoli.UseVisualStyleBackColor = true;
            this.Remove_Broccoli.Click += new System.EventHandler(this.Remove_Broccoli_Click);
            // 
            // Add_Pumpkin
            // 
            this.Add_Pumpkin.Location = new System.Drawing.Point(2050, 1070);
            this.Add_Pumpkin.Name = "Add_Pumpkin";
            this.Add_Pumpkin.Size = new System.Drawing.Size(122, 83);
            this.Add_Pumpkin.TabIndex = 93;
            this.Add_Pumpkin.Text = "Add";
            this.Add_Pumpkin.UseVisualStyleBackColor = true;
            this.Add_Pumpkin.Click += new System.EventHandler(this.Add_Pumpkin_Click);
            // 
            // Add_Cabbage
            // 
            this.Add_Cabbage.Location = new System.Drawing.Point(2050, 900);
            this.Add_Cabbage.Name = "Add_Cabbage";
            this.Add_Cabbage.Size = new System.Drawing.Size(122, 83);
            this.Add_Cabbage.TabIndex = 92;
            this.Add_Cabbage.Text = "Add";
            this.Add_Cabbage.UseVisualStyleBackColor = true;
            this.Add_Cabbage.Click += new System.EventHandler(this.Add_Cabbage_Click);
            // 
            // Add_Celery
            // 
            this.Add_Celery.Location = new System.Drawing.Point(2050, 730);
            this.Add_Celery.Name = "Add_Celery";
            this.Add_Celery.Size = new System.Drawing.Size(122, 83);
            this.Add_Celery.TabIndex = 91;
            this.Add_Celery.Text = "Add";
            this.Add_Celery.UseVisualStyleBackColor = true;
            this.Add_Celery.Click += new System.EventHandler(this.Add_Celery_Click);
            // 
            // Add_Bean
            // 
            this.Add_Bean.Location = new System.Drawing.Point(2050, 560);
            this.Add_Bean.Name = "Add_Bean";
            this.Add_Bean.Size = new System.Drawing.Size(122, 83);
            this.Add_Bean.TabIndex = 90;
            this.Add_Bean.Text = "Add";
            this.Add_Bean.UseVisualStyleBackColor = true;
            this.Add_Bean.Click += new System.EventHandler(this.Add_Bean_Click);
            // 
            // Add_Soy
            // 
            this.Add_Soy.Location = new System.Drawing.Point(2050, 390);
            this.Add_Soy.Name = "Add_Soy";
            this.Add_Soy.Size = new System.Drawing.Size(122, 83);
            this.Add_Soy.TabIndex = 89;
            this.Add_Soy.Text = "Add";
            this.Add_Soy.UseVisualStyleBackColor = true;
            this.Add_Soy.Click += new System.EventHandler(this.Add_Soy_Click);
            // 
            // Add_Broccoli
            // 
            this.Add_Broccoli.Location = new System.Drawing.Point(2050, 220);
            this.Add_Broccoli.Name = "Add_Broccoli";
            this.Add_Broccoli.Size = new System.Drawing.Size(122, 83);
            this.Add_Broccoli.TabIndex = 88;
            this.Add_Broccoli.Text = "Add";
            this.Add_Broccoli.UseVisualStyleBackColor = true;
            this.Add_Broccoli.Click += new System.EventHandler(this.Add_Broccoli_Click);
            // 
            // Add_Kiwi
            // 
            this.Add_Kiwi.Location = new System.Drawing.Point(400, 560);
            this.Add_Kiwi.Name = "Add_Kiwi";
            this.Add_Kiwi.Size = new System.Drawing.Size(122, 83);
            this.Add_Kiwi.TabIndex = 94;
            this.Add_Kiwi.Text = "Add";
            this.Add_Kiwi.UseVisualStyleBackColor = true;
            this.Add_Kiwi.Click += new System.EventHandler(this.Add_Kiwi_Click);
            // 
            // Add_Orange
            // 
            this.Add_Orange.Location = new System.Drawing.Point(400, 730);
            this.Add_Orange.Name = "Add_Orange";
            this.Add_Orange.Size = new System.Drawing.Size(122, 83);
            this.Add_Orange.TabIndex = 95;
            this.Add_Orange.Text = "Add";
            this.Add_Orange.UseVisualStyleBackColor = true;
            this.Add_Orange.Click += new System.EventHandler(this.Add_Orange_Click);
            // 
            // Add_Pineapple
            // 
            this.Add_Pineapple.Location = new System.Drawing.Point(400, 900);
            this.Add_Pineapple.Name = "Add_Pineapple";
            this.Add_Pineapple.Size = new System.Drawing.Size(122, 83);
            this.Add_Pineapple.TabIndex = 96;
            this.Add_Pineapple.Text = "Add";
            this.Add_Pineapple.UseVisualStyleBackColor = true;
            this.Add_Pineapple.Click += new System.EventHandler(this.Add_Pineapple_Click);
            // 
            // Add_Peach
            // 
            this.Add_Peach.Location = new System.Drawing.Point(400, 1070);
            this.Add_Peach.Name = "Add_Peach";
            this.Add_Peach.Size = new System.Drawing.Size(122, 83);
            this.Add_Peach.TabIndex = 97;
            this.Add_Peach.Text = "Add";
            this.Add_Peach.UseVisualStyleBackColor = true;
            this.Add_Peach.Click += new System.EventHandler(this.Add_Peach_Click);
            // 
            // Apple_Inv_Lab
            // 
            this.Apple_Inv_Lab.AutoSize = true;
            this.Apple_Inv_Lab.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Apple_Inv_Lab.Location = new System.Drawing.Point(548, 190);
            this.Apple_Inv_Lab.Name = "Apple_Inv_Lab";
            this.Apple_Inv_Lab.Size = new System.Drawing.Size(88, 31);
            this.Apple_Inv_Lab.TabIndex = 98;
            this.Apple_Inv_Lab.Text = "Apple";
            // 
            // Banana_Inv_Lab
            // 
            this.Banana_Inv_Lab.AutoSize = true;
            this.Banana_Inv_Lab.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Banana_Inv_Lab.Location = new System.Drawing.Point(529, 360);
            this.Banana_Inv_Lab.Name = "Banana_Inv_Lab";
            this.Banana_Inv_Lab.Size = new System.Drawing.Size(113, 31);
            this.Banana_Inv_Lab.TabIndex = 99;
            this.Banana_Inv_Lab.Text = "Banana";
            // 
            // Kiwi
            // 
            this.Kiwi.AutoSize = true;
            this.Kiwi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Kiwi.Location = new System.Drawing.Point(548, 530);
            this.Kiwi.Name = "Kiwi";
            this.Kiwi.Size = new System.Drawing.Size(68, 31);
            this.Kiwi.TabIndex = 100;
            this.Kiwi.Text = "Kiwi";
            // 
            // Orange
            // 
            this.Orange.AutoSize = true;
            this.Orange.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Orange.Location = new System.Drawing.Point(536, 700);
            this.Orange.Name = "Orange";
            this.Orange.Size = new System.Drawing.Size(110, 31);
            this.Orange.TabIndex = 101;
            this.Orange.Text = "Orange";
            // 
            // Pineapple
            // 
            this.Pineapple.AutoSize = true;
            this.Pineapple.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pineapple.Location = new System.Drawing.Point(523, 870);
            this.Pineapple.Name = "Pineapple";
            this.Pineapple.Size = new System.Drawing.Size(143, 31);
            this.Pineapple.TabIndex = 102;
            this.Pineapple.Text = "Pineapple";
            // 
            // Peach
            // 
            this.Peach.AutoSize = true;
            this.Peach.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Peach.Location = new System.Drawing.Point(544, 1040);
            this.Peach.Name = "Peach";
            this.Peach.Size = new System.Drawing.Size(96, 31);
            this.Peach.TabIndex = 103;
            this.Peach.Text = "Peach";
            // 
            // Pear
            // 
            this.Pear.AutoSize = true;
            this.Pear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pear.Location = new System.Drawing.Point(1095, 1040);
            this.Pear.Name = "Pear";
            this.Pear.Size = new System.Drawing.Size(75, 31);
            this.Pear.TabIndex = 109;
            this.Pear.Text = "Pear";
            // 
            // Mandarin
            // 
            this.Mandarin.AutoSize = true;
            this.Mandarin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mandarin.Location = new System.Drawing.Point(1070, 870);
            this.Mandarin.Name = "Mandarin";
            this.Mandarin.Size = new System.Drawing.Size(134, 31);
            this.Mandarin.TabIndex = 108;
            this.Mandarin.Text = "Mandarin";
            // 
            // Strawberry
            // 
            this.Strawberry.AutoSize = true;
            this.Strawberry.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Strawberry.Location = new System.Drawing.Point(1070, 700);
            this.Strawberry.Name = "Strawberry";
            this.Strawberry.Size = new System.Drawing.Size(156, 31);
            this.Strawberry.TabIndex = 107;
            this.Strawberry.Text = "Strawberry";
            this.Strawberry.Click += new System.EventHandler(this.label3_Click);
            // 
            // Grape
            // 
            this.Grape.AutoSize = true;
            this.Grape.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Grape.Location = new System.Drawing.Point(1099, 530);
            this.Grape.Name = "Grape";
            this.Grape.Size = new System.Drawing.Size(94, 31);
            this.Grape.TabIndex = 106;
            this.Grape.Text = "Grape";
            // 
            // Mango
            // 
            this.Mango.AutoSize = true;
            this.Mango.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mango.Location = new System.Drawing.Point(1087, 360);
            this.Mango.Name = "Mango";
            this.Mango.Size = new System.Drawing.Size(101, 31);
            this.Mango.TabIndex = 105;
            this.Mango.Text = "Mango";
            // 
            // Cherry
            // 
            this.Cherry.AutoSize = true;
            this.Cherry.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cherry.Location = new System.Drawing.Point(1099, 190);
            this.Cherry.Name = "Cherry";
            this.Cherry.Size = new System.Drawing.Size(102, 31);
            this.Cherry.TabIndex = 104;
            this.Cherry.Text = "Cherry";
            // 
            // Pumpkin
            // 
            this.Pumpkin.AutoSize = true;
            this.Pumpkin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pumpkin.Location = new System.Drawing.Point(2187, 1040);
            this.Pumpkin.Name = "Pumpkin";
            this.Pumpkin.Size = new System.Drawing.Size(126, 31);
            this.Pumpkin.TabIndex = 121;
            this.Pumpkin.Text = "Pumpkin";
            // 
            // Cabbage
            // 
            this.Cabbage.AutoSize = true;
            this.Cabbage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cabbage.Location = new System.Drawing.Point(2166, 870);
            this.Cabbage.Name = "Cabbage";
            this.Cabbage.Size = new System.Drawing.Size(131, 31);
            this.Cabbage.TabIndex = 120;
            this.Cabbage.Text = "Cabbage";
            // 
            // Celery
            // 
            this.Celery.AutoSize = true;
            this.Celery.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Celery.Location = new System.Drawing.Point(2179, 700);
            this.Celery.Name = "Celery";
            this.Celery.Size = new System.Drawing.Size(99, 31);
            this.Celery.TabIndex = 119;
            this.Celery.Text = "Celery";
            // 
            // Bean
            // 
            this.Bean.AutoSize = true;
            this.Bean.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bean.Location = new System.Drawing.Point(2191, 530);
            this.Bean.Name = "Bean";
            this.Bean.Size = new System.Drawing.Size(81, 31);
            this.Bean.TabIndex = 118;
            this.Bean.Text = "Bean";
            // 
            // Soy
            // 
            this.Soy.AutoSize = true;
            this.Soy.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Soy.Location = new System.Drawing.Point(2205, 360);
            this.Soy.Name = "Soy";
            this.Soy.Size = new System.Drawing.Size(64, 31);
            this.Soy.TabIndex = 117;
            this.Soy.Text = "Soy";
            // 
            // Broccoli
            // 
            this.Broccoli.AutoSize = true;
            this.Broccoli.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Broccoli.Location = new System.Drawing.Point(2191, 190);
            this.Broccoli.Name = "Broccoli";
            this.Broccoli.Size = new System.Drawing.Size(119, 31);
            this.Broccoli.TabIndex = 116;
            this.Broccoli.Text = "Broccoli";
            // 
            // Lettuce
            // 
            this.Lettuce.AutoSize = true;
            this.Lettuce.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lettuce.Location = new System.Drawing.Point(1636, 1040);
            this.Lettuce.Name = "Lettuce";
            this.Lettuce.Size = new System.Drawing.Size(111, 31);
            this.Lettuce.TabIndex = 115;
            this.Lettuce.Text = "Lettuce";
            // 
            // Cucumber
            // 
            this.Cucumber.AutoSize = true;
            this.Cucumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cucumber.Location = new System.Drawing.Point(1628, 870);
            this.Cucumber.Name = "Cucumber";
            this.Cucumber.Size = new System.Drawing.Size(147, 31);
            this.Cucumber.TabIndex = 114;
            this.Cucumber.Text = "Cucumber";
            // 
            // Tomato
            // 
            this.Tomato.AutoSize = true;
            this.Tomato.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tomato.Location = new System.Drawing.Point(1640, 700);
            this.Tomato.Name = "Tomato";
            this.Tomato.Size = new System.Drawing.Size(112, 31);
            this.Tomato.TabIndex = 113;
            this.Tomato.Text = "Tomato";
            // 
            // Corn
            // 
            this.Corn.AutoSize = true;
            this.Corn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Corn.Location = new System.Drawing.Point(1655, 530);
            this.Corn.Name = "Corn";
            this.Corn.Size = new System.Drawing.Size(77, 31);
            this.Corn.TabIndex = 112;
            this.Corn.Text = "Corn";
            // 
            // Carrot
            // 
            this.Carrot.AutoSize = true;
            this.Carrot.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Carrot.Location = new System.Drawing.Point(1636, 360);
            this.Carrot.Name = "Carrot";
            this.Carrot.Size = new System.Drawing.Size(96, 31);
            this.Carrot.TabIndex = 111;
            this.Carrot.Text = "Carrot";
            // 
            // Potato
            // 
            this.Potato.AutoSize = true;
            this.Potato.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Potato.Location = new System.Drawing.Point(1640, 190);
            this.Potato.Name = "Potato";
            this.Potato.Size = new System.Drawing.Size(99, 31);
            this.Potato.TabIndex = 110;
            this.Potato.Text = "Potato";
            // 
            // Reset_Inventory
            // 
            this.Reset_Inventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Reset_Inventory.Location = new System.Drawing.Point(1970, 1208);
            this.Reset_Inventory.Name = "Reset_Inventory";
            this.Reset_Inventory.Size = new System.Drawing.Size(343, 129);
            this.Reset_Inventory.TabIndex = 122;
            this.Reset_Inventory.Text = "Reset";
            this.Reset_Inventory.UseVisualStyleBackColor = true;
            this.Reset_Inventory.Click += new System.EventHandler(this.Reset_Inventory_Click);
            // 
            // Inventory_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2700, 1482);
            this.Controls.Add(this.Reset_Inventory);
            this.Controls.Add(this.Pumpkin);
            this.Controls.Add(this.Cabbage);
            this.Controls.Add(this.Celery);
            this.Controls.Add(this.Bean);
            this.Controls.Add(this.Soy);
            this.Controls.Add(this.Broccoli);
            this.Controls.Add(this.Lettuce);
            this.Controls.Add(this.Cucumber);
            this.Controls.Add(this.Tomato);
            this.Controls.Add(this.Corn);
            this.Controls.Add(this.Carrot);
            this.Controls.Add(this.Potato);
            this.Controls.Add(this.Pear);
            this.Controls.Add(this.Mandarin);
            this.Controls.Add(this.Strawberry);
            this.Controls.Add(this.Grape);
            this.Controls.Add(this.Mango);
            this.Controls.Add(this.Cherry);
            this.Controls.Add(this.Peach);
            this.Controls.Add(this.Pineapple);
            this.Controls.Add(this.Orange);
            this.Controls.Add(this.Kiwi);
            this.Controls.Add(this.Banana_Inv_Lab);
            this.Controls.Add(this.Apple_Inv_Lab);
            this.Controls.Add(this.Add_Peach);
            this.Controls.Add(this.Add_Pineapple);
            this.Controls.Add(this.Add_Orange);
            this.Controls.Add(this.Add_Kiwi);
            this.Controls.Add(this.Add_Pumpkin);
            this.Controls.Add(this.Add_Cabbage);
            this.Controls.Add(this.Add_Celery);
            this.Controls.Add(this.Add_Bean);
            this.Controls.Add(this.Add_Soy);
            this.Controls.Add(this.Add_Broccoli);
            this.Controls.Add(this.Remove_Pumpkin);
            this.Controls.Add(this.Remove_Cabbage);
            this.Controls.Add(this.Remove_Celery);
            this.Controls.Add(this.Remove_Bean);
            this.Controls.Add(this.Remove_Soy);
            this.Controls.Add(this.Remove_Broccoli);
            this.Controls.Add(this.Remove_Lettuce);
            this.Controls.Add(this.Remove_Cucumber);
            this.Controls.Add(this.Remove_Tomato);
            this.Controls.Add(this.Remove_Corn);
            this.Controls.Add(this.Remove_Carrot);
            this.Controls.Add(this.Remove_Potato);
            this.Controls.Add(this.Add_Lettuce);
            this.Controls.Add(this.Add_Cucumber);
            this.Controls.Add(this.Add_Tomato);
            this.Controls.Add(this.Add_Corn);
            this.Controls.Add(this.Add_Carrot);
            this.Controls.Add(this.Add_Potato);
            this.Controls.Add(this.Add_Pear);
            this.Controls.Add(this.Add_Mandarin);
            this.Controls.Add(this.Add_Strawberry);
            this.Controls.Add(this.Add_Grape);
            this.Controls.Add(this.Add_Mango);
            this.Controls.Add(this.Add_Cherry);
            this.Controls.Add(this.Remove_Pear);
            this.Controls.Add(this.Remove_Mandarin);
            this.Controls.Add(this.Remove_Strawberry);
            this.Controls.Add(this.Remove_Grape);
            this.Controls.Add(this.Remove_Mango);
            this.Controls.Add(this.Remove_Cherry);
            this.Controls.Add(this.Remove_Peach);
            this.Controls.Add(this.Remove_Pineapple);
            this.Controls.Add(this.Remove_Orange);
            this.Controls.Add(this.Remove_Kiwi);
            this.Controls.Add(this.Remove_Banana);
            this.Controls.Add(this.Add_Banana);
            this.Controls.Add(this.Remove_Apple);
            this.Controls.Add(this.Add_Apple);
            this.Controls.Add(this.Back_Inventory);
            this.Controls.Add(this.Inventory);
            this.Controls.Add(this.Pumpkin_txt);
            this.Controls.Add(this.Cabbage_txt);
            this.Controls.Add(this.Celery_txt);
            this.Controls.Add(this.Bean_txt);
            this.Controls.Add(this.Soy_txt);
            this.Controls.Add(this.Broccoli_txt);
            this.Controls.Add(this.Lettuce_txt);
            this.Controls.Add(this.Cucumber_txt);
            this.Controls.Add(this.Tomato_txt);
            this.Controls.Add(this.Corn_txt);
            this.Controls.Add(this.Carrot_txt);
            this.Controls.Add(this.Potato_txt);
            this.Controls.Add(this.Pear_txt);
            this.Controls.Add(this.Mandarin_txt);
            this.Controls.Add(this.Strawberry_txt);
            this.Controls.Add(this.Grape_txt);
            this.Controls.Add(this.Mango_txt);
            this.Controls.Add(this.Cherry_txt);
            this.Controls.Add(this.Peach_txt);
            this.Controls.Add(this.Pineapple_txt);
            this.Controls.Add(this.Orange_txt);
            this.Controls.Add(this.Kiwi_txt);
            this.Controls.Add(this.Banana_txt);
            this.Controls.Add(this.Apple_txt);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Inventory_form";
            this.Text = "Inventory";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Inventory_form_FormClosed);
            this.Load += new System.EventHandler(this.Inventory_form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox Apple_txt;
        private System.Windows.Forms.TextBox Banana_txt;
        private System.Windows.Forms.TextBox Kiwi_txt;
        private System.Windows.Forms.TextBox Peach_txt;
        private System.Windows.Forms.TextBox Pineapple_txt;
        private System.Windows.Forms.TextBox Orange_txt;
        private System.Windows.Forms.TextBox Pear_txt;
        private System.Windows.Forms.TextBox Mandarin_txt;
        private System.Windows.Forms.TextBox Strawberry_txt;
        private System.Windows.Forms.TextBox Grape_txt;
        private System.Windows.Forms.TextBox Mango_txt;
        private System.Windows.Forms.TextBox Cherry_txt;
        private System.Windows.Forms.TextBox Pumpkin_txt;
        private System.Windows.Forms.TextBox Cabbage_txt;
        private System.Windows.Forms.TextBox Celery_txt;
        private System.Windows.Forms.TextBox Bean_txt;
        private System.Windows.Forms.TextBox Soy_txt;
        private System.Windows.Forms.TextBox Broccoli_txt;
        private System.Windows.Forms.TextBox Lettuce_txt;
        private System.Windows.Forms.TextBox Cucumber_txt;
        private System.Windows.Forms.TextBox Tomato_txt;
        private System.Windows.Forms.TextBox Corn_txt;
        private System.Windows.Forms.TextBox Carrot_txt;
        private System.Windows.Forms.TextBox Potato_txt;
        private System.Windows.Forms.Label Inventory;
        private System.Windows.Forms.Button Back_Inventory;
        private System.Windows.Forms.Button Add_Apple;
        private System.Windows.Forms.Button Remove_Apple;
        private System.Windows.Forms.Button Add_Banana;
        private System.Windows.Forms.Button Remove_Banana;
        private System.Windows.Forms.Button Remove_Orange;
        private System.Windows.Forms.Button Remove_Kiwi;
        private System.Windows.Forms.Button Remove_Peach;
        private System.Windows.Forms.Button Remove_Pineapple;
        private System.Windows.Forms.Button Remove_Pear;
        private System.Windows.Forms.Button Remove_Mandarin;
        private System.Windows.Forms.Button Remove_Strawberry;
        private System.Windows.Forms.Button Remove_Grape;
        private System.Windows.Forms.Button Remove_Mango;
        private System.Windows.Forms.Button Remove_Cherry;
        private System.Windows.Forms.Button Add_Pear;
        private System.Windows.Forms.Button Add_Mandarin;
        private System.Windows.Forms.Button Add_Strawberry;
        private System.Windows.Forms.Button Add_Grape;
        private System.Windows.Forms.Button Add_Mango;
        private System.Windows.Forms.Button Add_Cherry;
        private System.Windows.Forms.Button Add_Lettuce;
        private System.Windows.Forms.Button Add_Cucumber;
        private System.Windows.Forms.Button Add_Tomato;
        private System.Windows.Forms.Button Add_Corn;
        private System.Windows.Forms.Button Add_Carrot;
        private System.Windows.Forms.Button Add_Potato;
        private System.Windows.Forms.Button Remove_Lettuce;
        private System.Windows.Forms.Button Remove_Cucumber;
        private System.Windows.Forms.Button Remove_Tomato;
        private System.Windows.Forms.Button Remove_Corn;
        private System.Windows.Forms.Button Remove_Carrot;
        private System.Windows.Forms.Button Remove_Potato;
        private System.Windows.Forms.Button Remove_Pumpkin;
        private System.Windows.Forms.Button Remove_Cabbage;
        private System.Windows.Forms.Button Remove_Celery;
        private System.Windows.Forms.Button Remove_Bean;
        private System.Windows.Forms.Button Remove_Soy;
        private System.Windows.Forms.Button Remove_Broccoli;
        private System.Windows.Forms.Button Add_Pumpkin;
        private System.Windows.Forms.Button Add_Cabbage;
        private System.Windows.Forms.Button Add_Celery;
        private System.Windows.Forms.Button Add_Bean;
        private System.Windows.Forms.Button Add_Soy;
        private System.Windows.Forms.Button Add_Broccoli;
        private System.Windows.Forms.Button Add_Kiwi;
        private System.Windows.Forms.Button Add_Orange;
        private System.Windows.Forms.Button Add_Pineapple;
        private System.Windows.Forms.Button Add_Peach;
        private System.Windows.Forms.Label Apple_Inv_Lab;
        private System.Windows.Forms.Label Banana_Inv_Lab;
        private System.Windows.Forms.Label Kiwi;
        private System.Windows.Forms.Label Orange;
        private System.Windows.Forms.Label Pineapple;
        private System.Windows.Forms.Label Peach;
        private System.Windows.Forms.Label Pear;
        private System.Windows.Forms.Label Mandarin;
        private System.Windows.Forms.Label Strawberry;
        private System.Windows.Forms.Label Grape;
        private System.Windows.Forms.Label Mango;
        private System.Windows.Forms.Label Cherry;
        private System.Windows.Forms.Label Pumpkin;
        private System.Windows.Forms.Label Cabbage;
        private System.Windows.Forms.Label Celery;
        private System.Windows.Forms.Label Bean;
        private System.Windows.Forms.Label Soy;
        private System.Windows.Forms.Label Broccoli;
        private System.Windows.Forms.Label Lettuce;
        private System.Windows.Forms.Label Cucumber;
        private System.Windows.Forms.Label Tomato;
        private System.Windows.Forms.Label Corn;
        private System.Windows.Forms.Label Carrot;
        private System.Windows.Forms.Label Potato;
        private System.Windows.Forms.Button Reset_Inventory;
    }
}