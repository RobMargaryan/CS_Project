﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RNX_Market    
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void POS_Main_Click(object sender, EventArgs e)
        {
            new POS_form().Show();
            this.Hide();
        }

        private void Inventory_Main_Click(object sender, EventArgs e)
        {
            new Inventory_form().Show();
            this.Hide();
        }
    }
}
