﻿namespace RNX_Market
{
    partial class POS_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(POS_form));
            this.Apple_POS = new System.Windows.Forms.Button();
            this.Cherry_POS = new System.Windows.Forms.Button();
            this.Mango_POS = new System.Windows.Forms.Button();
            this.Banana_POS = new System.Windows.Forms.Button();
            this.Strawberry_POS = new System.Windows.Forms.Button();
            this.Orange_POS = new System.Windows.Forms.Button();
            this.Grape_POS = new System.Windows.Forms.Button();
            this.Kiwi_POS = new System.Windows.Forms.Button();
            this.Celery_POS = new System.Windows.Forms.Button();
            this.Tomato_POS = new System.Windows.Forms.Button();
            this.Bean_POS = new System.Windows.Forms.Button();
            this.Corn_POS = new System.Windows.Forms.Button();
            this.Soy_POS = new System.Windows.Forms.Button();
            this.Carrot_POS = new System.Windows.Forms.Button();
            this.Broccoli_POS = new System.Windows.Forms.Button();
            this.Potato_POS = new System.Windows.Forms.Button();
            this.Pear_POS = new System.Windows.Forms.Button();
            this.Peach_POS = new System.Windows.Forms.Button();
            this.Mandarin_POS = new System.Windows.Forms.Button();
            this.Pineapple_POS = new System.Windows.Forms.Button();
            this.Pumpkin_POS = new System.Windows.Forms.Button();
            this.Lettuce_POS = new System.Windows.Forms.Button();
            this.Cabbage_POS = new System.Windows.Forms.Button();
            this.Cucumber_POS = new System.Windows.Forms.Button();
            this.POS = new System.Windows.Forms.Label();
            this.Back_POS = new System.Windows.Forms.Button();
            this.POS_Receipt = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.Total = new System.Windows.Forms.Button();
            this.SubTotal_txt = new System.Windows.Forms.TextBox();
            this.SubTotal_Label = new System.Windows.Forms.Label();
            this.Tax_label = new System.Windows.Forms.Label();
            this.Tax_txt = new System.Windows.Forms.TextBox();
            this.Total_label = new System.Windows.Forms.Label();
            this.Total_txt = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Apple_POS
            // 
            this.Apple_POS.Location = new System.Drawing.Point(311, 110);
            this.Apple_POS.Name = "Apple_POS";
            this.Apple_POS.Size = new System.Drawing.Size(185, 83);
            this.Apple_POS.TabIndex = 0;
            this.Apple_POS.Text = "Apple";
            this.Apple_POS.UseVisualStyleBackColor = true;
            this.Apple_POS.Click += new System.EventHandler(this.Apple_POS_Click);
            // 
            // Cherry_POS
            // 
            this.Cherry_POS.Location = new System.Drawing.Point(589, 110);
            this.Cherry_POS.Name = "Cherry_POS";
            this.Cherry_POS.Size = new System.Drawing.Size(185, 83);
            this.Cherry_POS.TabIndex = 1;
            this.Cherry_POS.Text = "Cherry";
            this.Cherry_POS.UseVisualStyleBackColor = true;
            this.Cherry_POS.Click += new System.EventHandler(this.Cherry_POS_Click);
            // 
            // Mango_POS
            // 
            this.Mango_POS.Location = new System.Drawing.Point(589, 265);
            this.Mango_POS.Name = "Mango_POS";
            this.Mango_POS.Size = new System.Drawing.Size(185, 83);
            this.Mango_POS.TabIndex = 3;
            this.Mango_POS.Text = "Mango";
            this.Mango_POS.UseVisualStyleBackColor = true;
            this.Mango_POS.Click += new System.EventHandler(this.Mango_POS_Click);
            // 
            // Banana_POS
            // 
            this.Banana_POS.Location = new System.Drawing.Point(311, 265);
            this.Banana_POS.Name = "Banana_POS";
            this.Banana_POS.Size = new System.Drawing.Size(185, 83);
            this.Banana_POS.TabIndex = 2;
            this.Banana_POS.Text = "Banana";
            this.Banana_POS.UseVisualStyleBackColor = true;
            this.Banana_POS.Click += new System.EventHandler(this.Banana_POS_Click);
            // 
            // Strawberry_POS
            // 
            this.Strawberry_POS.Location = new System.Drawing.Point(589, 556);
            this.Strawberry_POS.Name = "Strawberry_POS";
            this.Strawberry_POS.Size = new System.Drawing.Size(183, 83);
            this.Strawberry_POS.TabIndex = 7;
            this.Strawberry_POS.Text = "Strawberry";
            this.Strawberry_POS.UseVisualStyleBackColor = true;
            this.Strawberry_POS.Click += new System.EventHandler(this.Strawberry_POS_Click);
            // 
            // Orange_POS
            // 
            this.Orange_POS.Location = new System.Drawing.Point(311, 556);
            this.Orange_POS.Name = "Orange_POS";
            this.Orange_POS.Size = new System.Drawing.Size(185, 83);
            this.Orange_POS.TabIndex = 6;
            this.Orange_POS.Text = "Orange";
            this.Orange_POS.UseVisualStyleBackColor = true;
            this.Orange_POS.Click += new System.EventHandler(this.Orange_POS_Click);
            // 
            // Grape_POS
            // 
            this.Grape_POS.Location = new System.Drawing.Point(585, 408);
            this.Grape_POS.Name = "Grape_POS";
            this.Grape_POS.Size = new System.Drawing.Size(185, 83);
            this.Grape_POS.TabIndex = 5;
            this.Grape_POS.Text = "Grape";
            this.Grape_POS.UseVisualStyleBackColor = true;
            this.Grape_POS.Click += new System.EventHandler(this.Grape_POS_Click);
            // 
            // Kiwi_POS
            // 
            this.Kiwi_POS.Location = new System.Drawing.Point(311, 408);
            this.Kiwi_POS.Name = "Kiwi_POS";
            this.Kiwi_POS.Size = new System.Drawing.Size(185, 83);
            this.Kiwi_POS.TabIndex = 4;
            this.Kiwi_POS.Text = "Kiwi";
            this.Kiwi_POS.UseVisualStyleBackColor = true;
            this.Kiwi_POS.Click += new System.EventHandler(this.Kiwi_POS_Click);
            // 
            // Celery_POS
            // 
            this.Celery_POS.Location = new System.Drawing.Point(2169, 550);
            this.Celery_POS.Name = "Celery_POS";
            this.Celery_POS.Size = new System.Drawing.Size(185, 83);
            this.Celery_POS.TabIndex = 15;
            this.Celery_POS.Text = "Celery";
            this.Celery_POS.UseVisualStyleBackColor = true;
            this.Celery_POS.Click += new System.EventHandler(this.Celery_POS_Click);
            // 
            // Tomato_POS
            // 
            this.Tomato_POS.Location = new System.Drawing.Point(1906, 550);
            this.Tomato_POS.Name = "Tomato_POS";
            this.Tomato_POS.Size = new System.Drawing.Size(185, 83);
            this.Tomato_POS.TabIndex = 14;
            this.Tomato_POS.Text = "Tomato";
            this.Tomato_POS.UseVisualStyleBackColor = true;
            this.Tomato_POS.Click += new System.EventHandler(this.Tomato_POS_Click);
            // 
            // Bean_POS
            // 
            this.Bean_POS.Location = new System.Drawing.Point(2169, 402);
            this.Bean_POS.Name = "Bean_POS";
            this.Bean_POS.Size = new System.Drawing.Size(185, 83);
            this.Bean_POS.TabIndex = 13;
            this.Bean_POS.Text = "Bean";
            this.Bean_POS.UseVisualStyleBackColor = true;
            this.Bean_POS.Click += new System.EventHandler(this.Bean_POS_Click);
            // 
            // Corn_POS
            // 
            this.Corn_POS.Location = new System.Drawing.Point(1906, 402);
            this.Corn_POS.Name = "Corn_POS";
            this.Corn_POS.Size = new System.Drawing.Size(185, 83);
            this.Corn_POS.TabIndex = 12;
            this.Corn_POS.Text = "Corn";
            this.Corn_POS.UseVisualStyleBackColor = true;
            this.Corn_POS.Click += new System.EventHandler(this.Corn_POS_Click);
            // 
            // Soy_POS
            // 
            this.Soy_POS.Location = new System.Drawing.Point(2169, 259);
            this.Soy_POS.Name = "Soy_POS";
            this.Soy_POS.Size = new System.Drawing.Size(185, 83);
            this.Soy_POS.TabIndex = 11;
            this.Soy_POS.Text = "Soy";
            this.Soy_POS.UseVisualStyleBackColor = true;
            this.Soy_POS.Click += new System.EventHandler(this.Soy_POS_Click);
            // 
            // Carrot_POS
            // 
            this.Carrot_POS.Location = new System.Drawing.Point(1906, 259);
            this.Carrot_POS.Name = "Carrot_POS";
            this.Carrot_POS.Size = new System.Drawing.Size(185, 83);
            this.Carrot_POS.TabIndex = 10;
            this.Carrot_POS.Text = "Carrot";
            this.Carrot_POS.UseVisualStyleBackColor = true;
            this.Carrot_POS.Click += new System.EventHandler(this.Carrot_POS_Click);
            // 
            // Broccoli_POS
            // 
            this.Broccoli_POS.Location = new System.Drawing.Point(2169, 104);
            this.Broccoli_POS.Name = "Broccoli_POS";
            this.Broccoli_POS.Size = new System.Drawing.Size(185, 83);
            this.Broccoli_POS.TabIndex = 9;
            this.Broccoli_POS.Text = "Broccoli";
            this.Broccoli_POS.UseVisualStyleBackColor = true;
            this.Broccoli_POS.Click += new System.EventHandler(this.Broccoli_POS_Click);
            // 
            // Potato_POS
            // 
            this.Potato_POS.Location = new System.Drawing.Point(1906, 104);
            this.Potato_POS.Name = "Potato_POS";
            this.Potato_POS.Size = new System.Drawing.Size(185, 83);
            this.Potato_POS.TabIndex = 8;
            this.Potato_POS.Text = "Potato";
            this.Potato_POS.UseVisualStyleBackColor = true;
            this.Potato_POS.Click += new System.EventHandler(this.Potato_POS_Click);
            // 
            // Pear_POS
            // 
            this.Pear_POS.Location = new System.Drawing.Point(587, 841);
            this.Pear_POS.Name = "Pear_POS";
            this.Pear_POS.Size = new System.Drawing.Size(185, 83);
            this.Pear_POS.TabIndex = 19;
            this.Pear_POS.Text = "Pear";
            this.Pear_POS.UseVisualStyleBackColor = true;
            this.Pear_POS.Click += new System.EventHandler(this.Pear_POS_Click);
            // 
            // Peach_POS
            // 
            this.Peach_POS.Location = new System.Drawing.Point(311, 846);
            this.Peach_POS.Name = "Peach_POS";
            this.Peach_POS.Size = new System.Drawing.Size(185, 83);
            this.Peach_POS.TabIndex = 18;
            this.Peach_POS.Text = "Peach";
            this.Peach_POS.UseVisualStyleBackColor = true;
            this.Peach_POS.Click += new System.EventHandler(this.Peach_POS_Click);
            // 
            // Mandarin_POS
            // 
            this.Mandarin_POS.Location = new System.Drawing.Point(587, 694);
            this.Mandarin_POS.Name = "Mandarin_POS";
            this.Mandarin_POS.Size = new System.Drawing.Size(183, 83);
            this.Mandarin_POS.TabIndex = 17;
            this.Mandarin_POS.Text = "Mandarin";
            this.Mandarin_POS.UseVisualStyleBackColor = true;
            this.Mandarin_POS.Click += new System.EventHandler(this.Mandarin_POS_Click);
            // 
            // Pineapple_POS
            // 
            this.Pineapple_POS.Location = new System.Drawing.Point(311, 694);
            this.Pineapple_POS.Name = "Pineapple_POS";
            this.Pineapple_POS.Size = new System.Drawing.Size(185, 83);
            this.Pineapple_POS.TabIndex = 16;
            this.Pineapple_POS.Text = "Pineapple";
            this.Pineapple_POS.UseVisualStyleBackColor = true;
            this.Pineapple_POS.Click += new System.EventHandler(this.Pineapple_POS_Click);
            // 
            // Pumpkin_POS
            // 
            this.Pumpkin_POS.Location = new System.Drawing.Point(2169, 835);
            this.Pumpkin_POS.Name = "Pumpkin_POS";
            this.Pumpkin_POS.Size = new System.Drawing.Size(185, 83);
            this.Pumpkin_POS.TabIndex = 23;
            this.Pumpkin_POS.Text = "Pumpkin";
            this.Pumpkin_POS.UseVisualStyleBackColor = true;
            this.Pumpkin_POS.Click += new System.EventHandler(this.Pumpkin_POS_Click);
            // 
            // Lettuce_POS
            // 
            this.Lettuce_POS.Location = new System.Drawing.Point(1906, 840);
            this.Lettuce_POS.Name = "Lettuce_POS";
            this.Lettuce_POS.Size = new System.Drawing.Size(185, 83);
            this.Lettuce_POS.TabIndex = 22;
            this.Lettuce_POS.Text = "Lettuce";
            this.Lettuce_POS.UseVisualStyleBackColor = true;
            this.Lettuce_POS.Click += new System.EventHandler(this.Lettuce_POS_Click);
            // 
            // Cabbage_POS
            // 
            this.Cabbage_POS.Location = new System.Drawing.Point(2169, 688);
            this.Cabbage_POS.Name = "Cabbage_POS";
            this.Cabbage_POS.Size = new System.Drawing.Size(185, 83);
            this.Cabbage_POS.TabIndex = 21;
            this.Cabbage_POS.Text = "Cabbage";
            this.Cabbage_POS.UseVisualStyleBackColor = true;
            this.Cabbage_POS.Click += new System.EventHandler(this.Cabbage_POS_Click);
            // 
            // Cucumber_POS
            // 
            this.Cucumber_POS.Location = new System.Drawing.Point(1906, 688);
            this.Cucumber_POS.Name = "Cucumber_POS";
            this.Cucumber_POS.Size = new System.Drawing.Size(185, 83);
            this.Cucumber_POS.TabIndex = 20;
            this.Cucumber_POS.Text = "Cucumber";
            this.Cucumber_POS.UseVisualStyleBackColor = true;
            this.Cucumber_POS.Click += new System.EventHandler(this.Cucumber_POS_Click);
            // 
            // POS
            // 
            this.POS.AutoSize = true;
            this.POS.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.POS.Location = new System.Drawing.Point(1159, 35);
            this.POS.Name = "POS";
            this.POS.Size = new System.Drawing.Size(343, 55);
            this.POS.TabIndex = 24;
            this.POS.Text = "Point Of Sales";
            // 
            // Back_POS
            // 
            this.Back_POS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Back_POS.Location = new System.Drawing.Point(26, 1223);
            this.Back_POS.Name = "Back_POS";
            this.Back_POS.Size = new System.Drawing.Size(248, 63);
            this.Back_POS.TabIndex = 50;
            this.Back_POS.Text = "Back ";
            this.Back_POS.UseVisualStyleBackColor = true;
            this.Back_POS.Click += new System.EventHandler(this.Back_POS_Click);
            // 
            // POS_Receipt
            // 
            this.POS_Receipt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.POS_Receipt.Location = new System.Drawing.Point(909, 936);
            this.POS_Receipt.Multiline = true;
            this.POS_Receipt.Name = "POS_Receipt";
            this.POS_Receipt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.POS_Receipt.Size = new System.Drawing.Size(893, 432);
            this.POS_Receipt.TabIndex = 51;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // Total
            // 
            this.Total.Location = new System.Drawing.Point(1924, 1277);
            this.Total.Name = "Total";
            this.Total.Size = new System.Drawing.Size(338, 91);
            this.Total.TabIndex = 53;
            this.Total.Text = "Total";
            this.Total.UseVisualStyleBackColor = true;
            this.Total.Click += new System.EventHandler(this.Total_Click);
            // 
            // SubTotal_txt
            // 
            this.SubTotal_txt.Location = new System.Drawing.Point(1290, 788);
            this.SubTotal_txt.Multiline = true;
            this.SubTotal_txt.Name = "SubTotal_txt";
            this.SubTotal_txt.Size = new System.Drawing.Size(253, 47);
            this.SubTotal_txt.TabIndex = 54;
            this.SubTotal_txt.Text = "0";
            // 
            // SubTotal_Label
            // 
            this.SubTotal_Label.AutoSize = true;
            this.SubTotal_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubTotal_Label.Location = new System.Drawing.Point(1115, 787);
            this.SubTotal_Label.Name = "SubTotal_Label";
            this.SubTotal_Label.Size = new System.Drawing.Size(154, 37);
            this.SubTotal_Label.TabIndex = 55;
            this.SubTotal_Label.Text = "SubTotal";
            // 
            // Tax_label
            // 
            this.Tax_label.AutoSize = true;
            this.Tax_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tax_label.Location = new System.Drawing.Point(1115, 714);
            this.Tax_label.Name = "Tax_label";
            this.Tax_label.Size = new System.Drawing.Size(73, 37);
            this.Tax_label.TabIndex = 56;
            this.Tax_label.Text = "Tax";
            // 
            // Tax_txt
            // 
            this.Tax_txt.Location = new System.Drawing.Point(1290, 714);
            this.Tax_txt.Multiline = true;
            this.Tax_txt.Name = "Tax_txt";
            this.Tax_txt.Size = new System.Drawing.Size(253, 47);
            this.Tax_txt.TabIndex = 57;
            this.Tax_txt.Text = "0";
            // 
            // Total_label
            // 
            this.Total_label.AutoSize = true;
            this.Total_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Total_label.Location = new System.Drawing.Point(1115, 866);
            this.Total_label.Name = "Total_label";
            this.Total_label.Size = new System.Drawing.Size(94, 37);
            this.Total_label.TabIndex = 58;
            this.Total_label.Text = "Total";
            // 
            // Total_txt
            // 
            this.Total_txt.Location = new System.Drawing.Point(1290, 866);
            this.Total_txt.Multiline = true;
            this.Total_txt.Name = "Total_txt";
            this.Total_txt.Size = new System.Drawing.Size(253, 47);
            this.Total_txt.TabIndex = 59;
            this.Total_txt.Text = "0";
            // 
            // POS_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2476, 1446);
            this.Controls.Add(this.Total_txt);
            this.Controls.Add(this.Total_label);
            this.Controls.Add(this.Tax_txt);
            this.Controls.Add(this.Tax_label);
            this.Controls.Add(this.SubTotal_Label);
            this.Controls.Add(this.SubTotal_txt);
            this.Controls.Add(this.Total);
            this.Controls.Add(this.POS_Receipt);
            this.Controls.Add(this.Back_POS);
            this.Controls.Add(this.POS);
            this.Controls.Add(this.Pumpkin_POS);
            this.Controls.Add(this.Lettuce_POS);
            this.Controls.Add(this.Cabbage_POS);
            this.Controls.Add(this.Cucumber_POS);
            this.Controls.Add(this.Pear_POS);
            this.Controls.Add(this.Peach_POS);
            this.Controls.Add(this.Mandarin_POS);
            this.Controls.Add(this.Pineapple_POS);
            this.Controls.Add(this.Celery_POS);
            this.Controls.Add(this.Tomato_POS);
            this.Controls.Add(this.Bean_POS);
            this.Controls.Add(this.Corn_POS);
            this.Controls.Add(this.Soy_POS);
            this.Controls.Add(this.Carrot_POS);
            this.Controls.Add(this.Broccoli_POS);
            this.Controls.Add(this.Potato_POS);
            this.Controls.Add(this.Strawberry_POS);
            this.Controls.Add(this.Orange_POS);
            this.Controls.Add(this.Grape_POS);
            this.Controls.Add(this.Kiwi_POS);
            this.Controls.Add(this.Mango_POS);
            this.Controls.Add(this.Banana_POS);
            this.Controls.Add(this.Cherry_POS);
            this.Controls.Add(this.Apple_POS);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "POS_form";
            this.Text = "Point Of Sales";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Apple_POS;
        private System.Windows.Forms.Button Cherry_POS;
        private System.Windows.Forms.Button Mango_POS;
        private System.Windows.Forms.Button Banana_POS;
        private System.Windows.Forms.Button Strawberry_POS;
        private System.Windows.Forms.Button Orange_POS;
        private System.Windows.Forms.Button Grape_POS;
        private System.Windows.Forms.Button Kiwi_POS;
        private System.Windows.Forms.Button Celery_POS;
        private System.Windows.Forms.Button Tomato_POS;
        private System.Windows.Forms.Button Bean_POS;
        private System.Windows.Forms.Button Corn_POS;
        private System.Windows.Forms.Button Soy_POS;
        private System.Windows.Forms.Button Carrot_POS;
        private System.Windows.Forms.Button Broccoli_POS;
        private System.Windows.Forms.Button Potato_POS;
        private System.Windows.Forms.Button Pear_POS;
        private System.Windows.Forms.Button Peach_POS;
        private System.Windows.Forms.Button Mandarin_POS;
        private System.Windows.Forms.Button Pineapple_POS;
        private System.Windows.Forms.Button Pumpkin_POS;
        private System.Windows.Forms.Button Lettuce_POS;
        private System.Windows.Forms.Button Cabbage_POS;
        private System.Windows.Forms.Button Cucumber_POS;
        private System.Windows.Forms.Label POS;
        private System.Windows.Forms.Button Back_POS;
        private System.Windows.Forms.TextBox POS_Receipt;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Button Total;
        private System.Windows.Forms.TextBox SubTotal_txt;
        private System.Windows.Forms.Label SubTotal_Label;
        private System.Windows.Forms.Label Tax_label;
        private System.Windows.Forms.TextBox Tax_txt;
        private System.Windows.Forms.Label Total_label;
        private System.Windows.Forms.TextBox Total_txt;
    }
}