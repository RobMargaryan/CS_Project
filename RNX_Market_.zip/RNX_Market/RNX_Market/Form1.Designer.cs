﻿namespace RNX_Market
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.RNX_Main = new System.Windows.Forms.Label();
            this.POS_Main = new System.Windows.Forms.Button();
            this.Inventory_Main = new System.Windows.Forms.Button();
            this.Version = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // RNX_Main
            // 
            this.RNX_Main.AutoSize = true;
            this.RNX_Main.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RNX_Main.Location = new System.Drawing.Point(1399, 263);
            this.RNX_Main.Name = "RNX_Main";
            this.RNX_Main.Size = new System.Drawing.Size(288, 61);
            this.RNX_Main.TabIndex = 0;
            this.RNX_Main.Text = "RNX_Main";
            // 
            // POS_Main
            // 
            this.POS_Main.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.POS_Main.Location = new System.Drawing.Point(710, 610);
            this.POS_Main.Name = "POS_Main";
            this.POS_Main.Size = new System.Drawing.Size(421, 197);
            this.POS_Main.TabIndex = 1;
            this.POS_Main.Text = "Point of Sales";
            this.POS_Main.UseVisualStyleBackColor = true;
            this.POS_Main.Click += new System.EventHandler(this.POS_Main_Click);
            // 
            // Inventory_Main
            // 
            this.Inventory_Main.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Inventory_Main.Location = new System.Drawing.Point(1989, 610);
            this.Inventory_Main.Name = "Inventory_Main";
            this.Inventory_Main.Size = new System.Drawing.Size(421, 197);
            this.Inventory_Main.TabIndex = 2;
            this.Inventory_Main.Text = "Inventory";
            this.Inventory_Main.UseVisualStyleBackColor = true;
            this.Inventory_Main.Click += new System.EventHandler(this.Inventory_Main_Click);
            // 
            // Version
            // 
            this.Version.AutoSize = true;
            this.Version.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Version.Location = new System.Drawing.Point(12, 9);
            this.Version.Name = "Version";
            this.Version.Size = new System.Drawing.Size(251, 42);
            this.Version.TabIndex = 3;
            this.Version.Text = "Version 1.0.0";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2685, 1518);
            this.Controls.Add(this.Version);
            this.Controls.Add(this.Inventory_Main);
            this.Controls.Add(this.POS_Main);
            this.Controls.Add(this.RNX_Main);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Main";
            this.Text = "Main";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label RNX_Main;
        private System.Windows.Forms.Button POS_Main;
        private System.Windows.Forms.Button Inventory_Main;
        private System.Windows.Forms.Label Version;
    }
}

