﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RNX_Market
{
    public partial class POS_form : Form
    {
        public POS_form()
        {
            InitializeComponent();
        }

        private void Back_POS_Click(object sender, EventArgs e)
        {
            new Main().Show();
            this.Hide();
        }

        private void Total_Click(object sender, EventArgs e)
        {
            double iTax = Convert.ToDouble(Tax_txt.Text);
            double iSubtotal = Convert.ToDouble(SubTotal_txt.Text);
            double iTotal = iTax + iSubtotal;
            Total_txt.Text = iTotal.ToString();

            POS_Receipt.AppendText("\t\t" + "            RNX Market" + Environment.NewLine);
            POS_Receipt.AppendText("\t\t" +"Good food makes good mood" + Environment.NewLine);
            POS_Receipt.AppendText("=====================================================" + Environment.NewLine);
            POS_Receipt.AppendText("\t\t" + "      Baghramyan 26" + Environment.NewLine);           
            POS_Receipt.AppendText("\t\t" + "  Yerevan, Armenia" + Environment.NewLine);
            POS_Receipt.AppendText("=====================================================" + Environment.NewLine);
            POS_Receipt.AppendText("\t\t" + "Tax" + "\t\t" + iTax + Environment.NewLine);
            POS_Receipt.AppendText("\t\t" + "Subtotal" + "\t\t" + iSubtotal + Environment.NewLine);
            POS_Receipt.AppendText("\t\t" + "Total" + "\t\t" + iTotal + Environment.NewLine);
            POS_Receipt.AppendText("=====================================================" + Environment.NewLine);
        }

        private void Apple_POS_Click(object sender, EventArgs e)
        {
            var POS_Apple = Convert.ToInt32(Properties.Settings.Default.Apple_txt);
            if (POS_Apple == 0)
            {
                MessageBox.Show("You are out of Apple's");
            }
            else
            {
                POS_Receipt.AppendText("Apple" + "\t\t\t\t\t" +"  420AMD"+Environment.NewLine);
                POS_Apple = POS_Apple - 1;
                Properties.Settings.Default.Apple_txt = POS_Apple.ToString();
                var Apple = Convert.ToInt32(SubTotal_txt.Text);
                Apple = Apple + 420;
                double Apple_Tax = Convert.ToDouble(Tax_txt.Text);
                Apple_Tax = Apple_Tax + (Apple * 20) / 100;
                Tax_txt.Text = Apple_Tax.ToString();
                SubTotal_txt.Text = Apple.ToString();

            }
        }

        private void Banana_POS_Click(object sender, EventArgs e)
        {
            var POS_Banana = Convert.ToInt32(Properties.Settings.Default.Banana_txt);
            if (POS_Banana == 0)
            {
                MessageBox.Show("You are out of Banana's");
            }
            else
            {
                POS_Receipt.AppendText("Banana" + "\t\t\t\t\t" + "  580AMD" + Environment.NewLine);
                POS_Banana = POS_Banana - 1;
                Properties.Settings.Default.Banana_txt = POS_Banana.ToString();
                var Banana = Convert.ToInt32(SubTotal_txt.Text);
                Banana = Banana + 580;
                double Banana_Tax = Convert.ToDouble(Tax_txt.Text);
                Banana_Tax = Banana_Tax + Banana * 0.2;
                Tax_txt.Text = Banana_Tax.ToString();
                SubTotal_txt.Text = Banana.ToString();

            }
        }

        private void Peach_POS_Click(object sender, EventArgs e)
        {
            var POS_Peach = Convert.ToInt32(Properties.Settings.Default.Peach_txt);
            if (POS_Peach == 0)
            {
                MessageBox.Show("You are out of Peach's");
            }
            else
            {
                POS_Receipt.AppendText("Peach" + "\t\t\t\t\t" + "  750AMD" + Environment.NewLine);
                POS_Peach= POS_Peach- 1;
                Properties.Settings.Default.Peach_txt = POS_Peach.ToString();
                var Peach = Convert.ToInt32(SubTotal_txt.Text);
                Peach = Peach + 750;
                double Peach_Tax = Convert.ToDouble(Tax_txt.Text);
                Peach_Tax = Peach_Tax + Peach * 0.2;
                Tax_txt.Text = Peach_Tax.ToString();
                SubTotal_txt.Text = Peach.ToString();

            }
        }

        private void Pear_POS_Click(object sender, EventArgs e)
        {
            var POS_Pear = Convert.ToInt32(Properties.Settings.Default.Pear_txt);
            if (POS_Pear == 0)
            {
                MessageBox.Show("You are out of Pear's");
            }
            else
            {
                POS_Receipt.AppendText("Pear" + "\t\t\t\t\t" + "1470AMD" + Environment.NewLine);
                POS_Pear = POS_Pear - 1;
                Properties.Settings.Default.Pear_txt = POS_Pear.ToString();
                var Pear = Convert.ToInt32(SubTotal_txt.Text);
                Pear = Pear + 2170;
                double Pear_Tax = Convert.ToDouble(Tax_txt.Text);
                Pear_Tax = Pear_Tax + Pear * 0.2;
                Tax_txt.Text = Pear_Tax.ToString();
                SubTotal_txt.Text = Pear.ToString();

            }
        }

        private void Corn_POS_Click(object sender, EventArgs e)
        {
            var POS_Corn = Convert.ToInt32(Properties.Settings.Default.Corn_txt);
            if (POS_Corn == 0)
            {
                MessageBox.Show("You are out of Corn's");
            }
            else
            {
                POS_Receipt.AppendText("Corn" + "\t\t\t\t\t" + "  750AMD" + Environment.NewLine);
                POS_Corn= POS_Corn- 1;
                Properties.Settings.Default.Corn_txt = POS_Corn.ToString();
                var Corn = Convert.ToInt32(SubTotal_txt.Text);
                Corn = Corn + 750;
                double Corn_Tax = Convert.ToDouble(Tax_txt.Text);
                Corn_Tax = Corn_Tax + Corn * 0.2;
                Tax_txt.Text = Corn_Tax.ToString();
                SubTotal_txt.Text = Corn.ToString();

            }
        }

        private void Bean_POS_Click(object sender, EventArgs e)
        {
            var POS_Bean = Convert.ToInt32(Properties.Settings.Default.Bean_txt);
            if (POS_Bean == 0)
            {
                MessageBox.Show("You are out of Bean's");
            }
            else
            {
                POS_Receipt.AppendText("Bean" + "\t\t\t\t\t" + "1530AMD" + Environment.NewLine);
                POS_Bean = POS_Bean - 1;
                Properties.Settings.Default.Bean_txt = POS_Bean.ToString();
                var Bean = Convert.ToInt32(SubTotal_txt.Text);
                Bean = Bean + 1530;
                double Bean_Tax = Convert.ToDouble(Tax_txt.Text);
                Bean_Tax = Bean_Tax + Bean * 0.2;
                Tax_txt.Text = Bean_Tax.ToString();
                SubTotal_txt.Text = Bean.ToString();

            }
        }

        private void Kiwi_POS_Click(object sender, EventArgs e)
        {
            var POS_Kiwi = Convert.ToInt32(Properties.Settings.Default.Kiwi_txt);
            if (POS_Kiwi == 0)
            {
                MessageBox.Show("You are out of Kiwi's");
            }
            else
            {
                POS_Receipt.AppendText("Kiwi" + "\t\t\t\t\t" + "  660AMD" + Environment.NewLine);
                POS_Kiwi = POS_Kiwi - 1;
                Properties.Settings.Default.Kiwi_txt = POS_Kiwi.ToString();
                var Kiwi = Convert.ToInt32(SubTotal_txt.Text);
                Kiwi = Kiwi + 660;
                double Kiwi_Tax = Convert.ToDouble(Tax_txt.Text);
                Kiwi_Tax = Kiwi_Tax + Kiwi * 0.2;
                Tax_txt.Text = Kiwi_Tax.ToString();
                SubTotal_txt.Text = Kiwi.ToString();

            }
        }

        private void Pineapple_POS_Click(object sender, EventArgs e)
        {
            var POS_Pineapple = Convert.ToInt32(Properties.Settings.Default.Pineapple_txt);
            if (POS_Pineapple == 0)
            {
                MessageBox.Show("You are out of Pineapple's");
            }
            else
            {
                POS_Receipt.AppendText("Pineapple" + "\t\t\t\t\t" + "1480AMD" + Environment.NewLine);
                POS_Pineapple = POS_Pineapple - 1;
                Properties.Settings.Default.Pineapple_txt = POS_Pineapple.ToString();
                var Pineapple = Convert.ToInt32(SubTotal_txt.Text);
                Pineapple = Pineapple + 1480;
                double Pineapple_Tax = Convert.ToDouble(Tax_txt.Text);
                Pineapple_Tax = Pineapple_Tax + Pineapple * 0.2;
                Tax_txt.Text = Pineapple_Tax.ToString();
                SubTotal_txt.Text = Pineapple.ToString();

            }
        }

        private void Orange_POS_Click(object sender, EventArgs e)
        {
            var POS_Orange = Convert.ToInt32(Properties.Settings.Default.Orange_txt);
            if (POS_Orange == 0)
            {
                MessageBox.Show("You are out of Orange's");
            }
            else
            {
                POS_Receipt.AppendText("Orange" + "\t\t\t\t\t" + "  850AMD" + Environment.NewLine);
                POS_Orange = POS_Orange - 1;
                Properties.Settings.Default.Orange_txt = POS_Orange.ToString();
                var Orange = Convert.ToInt32(SubTotal_txt.Text);
                Orange = Orange + 850;
                double Orange_Tax = Convert.ToDouble(Tax_txt.Text);
                Orange_Tax = Orange_Tax + Orange * 0.2;
                Tax_txt.Text = Orange_Tax.ToString();
                SubTotal_txt.Text = Orange.ToString();

            }
        }

        private void Cherry_POS_Click(object sender, EventArgs e)
        {
            var POS_Cherry = Convert.ToInt32(Properties.Settings.Default.Cherry_txt);
            if (POS_Cherry == 0)
            {
                MessageBox.Show("You are out of Cherry's");
            }
            else
            {
                POS_Receipt.AppendText("Cherry" + "\t\t\t\t\t" + "4250AMD" + Environment.NewLine);
                POS_Cherry = POS_Cherry - 1;
                Properties.Settings.Default.Cherry_txt = POS_Cherry.ToString();
                var Cherry = Convert.ToInt32(SubTotal_txt.Text);
                Cherry = Cherry + 4250;
                double Cherry_Tax = Convert.ToDouble(Tax_txt.Text);
                Cherry_Tax = Cherry_Tax + Cherry * 0.2;
                Tax_txt.Text = Cherry_Tax.ToString();
                SubTotal_txt.Text = Cherry.ToString();

            }
        }

        private void Mango_POS_Click(object sender, EventArgs e)
        {
            var POS_Mango = Convert.ToInt32(Properties.Settings.Default.Mango_txt);
            if (POS_Mango == 0)
            {
                MessageBox.Show("You are out of Mango's");
            }
            else
            {
                POS_Receipt.AppendText("Mango" + "\t\t\t\t\t" + "4890AMD" + Environment.NewLine);
                POS_Mango = POS_Mango - 1;
                Properties.Settings.Default.Mango_txt = POS_Mango.ToString();
                var Mango = Convert.ToInt32(SubTotal_txt.Text);
                Mango = Mango + 4890;
                double Mango_Tax = Convert.ToDouble(Tax_txt.Text);
                Mango_Tax = Mango_Tax + Mango * 0.2;
                Tax_txt.Text = Mango_Tax.ToString();
                SubTotal_txt.Text = Mango.ToString();

            }
        }

        private void Grape_POS_Click(object sender, EventArgs e)
        {
            var POS_Grape = Convert.ToInt32(Properties.Settings.Default.Grape_txt);
            if (POS_Grape == 0)
            {
                MessageBox.Show("You are out of Grape's");
            }
            else
            {
                POS_Receipt.AppendText("Grape" + "\t\t\t\t\t" + "  800AMD" + Environment.NewLine);
                POS_Grape = POS_Grape - 1;
                Properties.Settings.Default.Grape_txt = POS_Grape.ToString();
                var Grape = Convert.ToInt32(SubTotal_txt.Text);
                Grape = Grape + 800;
                double Grape_Tax = Convert.ToDouble(Tax_txt.Text);
                Grape_Tax = Grape_Tax + Grape * 0.2;
                Tax_txt.Text = Grape_Tax.ToString();
                SubTotal_txt.Text = Grape.ToString();

            }
        }

        private void Strawberry_POS_Click(object sender, EventArgs e)
        {
            var POS_Strawberry = Convert.ToInt32(Properties.Settings.Default.Strawberry_txt);
            if (POS_Strawberry == 0)
            {
                MessageBox.Show("You are out of Strawberry's");
            }
            else
            {
                POS_Receipt.AppendText("Strawberry" + "\t\t\t\t" + "1390AMD" + Environment.NewLine);
                POS_Strawberry = POS_Strawberry - 1;
                Properties.Settings.Default.Strawberry_txt = POS_Strawberry.ToString();
                var Strawberry = Convert.ToInt32(SubTotal_txt.Text);
                Strawberry = Strawberry + 1500;
                double Strawberry_Tax = Convert.ToDouble(Tax_txt.Text);
                Strawberry_Tax = Strawberry_Tax + Strawberry * 0.2;
                Tax_txt.Text = Strawberry_Tax.ToString();
                SubTotal_txt.Text = Strawberry.ToString();

            }
        }

        private void Mandarin_POS_Click(object sender, EventArgs e)
        {
            var POS_Mandarin = Convert.ToInt32(Properties.Settings.Default.Mandarin_txt);
            if (POS_Mandarin == 0)
            {
                MessageBox.Show("You are out of Mandarin's");
            }
            else
            {
                POS_Receipt.AppendText("Mandarin" + "\t\t\t\t\t" + "  490AMD" + Environment.NewLine);
                POS_Mandarin = POS_Mandarin - 1;
                Properties.Settings.Default.Mandarin_txt = POS_Mandarin.ToString();
                var Mandarin = Convert.ToInt32(SubTotal_txt.Text);
                Mandarin = Mandarin + 490;
                double Mandarin_Tax = Convert.ToDouble(Tax_txt.Text);
                Mandarin_Tax = Mandarin_Tax + Mandarin * 0.2;
                Tax_txt.Text = Mandarin_Tax.ToString();
                SubTotal_txt.Text = Mandarin.ToString();

            }

        }

        private void Potato_POS_Click(object sender, EventArgs e)
        {
            var POS_Potato = Convert.ToInt32(Properties.Settings.Default.Potato_txt);
            if (POS_Potato == 0)
            {
                MessageBox.Show("You are out of Potato's");
            }
            else
            {
                POS_Receipt.AppendText("Potato" + "\t\t\t\t\t" + "  300AMD" + Environment.NewLine);
                POS_Potato = POS_Potato - 1;
                Properties.Settings.Default.Potato_txt = POS_Potato.ToString();
                var Potato = Convert.ToInt32(SubTotal_txt.Text);
                Potato = Potato + 300;
                double Potato_Tax = Convert.ToDouble(Tax_txt.Text);
                Potato_Tax = Potato_Tax + Potato * 0.2;
                Tax_txt.Text = Potato_Tax.ToString();
                SubTotal_txt.Text = Potato.ToString();

            }
        }

        private void Carrot_POS_Click(object sender, EventArgs e)
        {
            var POS_Carrot = Convert.ToInt32(Properties.Settings.Default.Carrot_txt);
            if (POS_Carrot == 0)
            {
                MessageBox.Show("You are out of Carrot's");
            }
            else
            {
                POS_Receipt.AppendText("Carrot" + "\t\t\t\t\t" + "  320AMD" + Environment.NewLine);
                POS_Carrot = POS_Carrot - 1;
                Properties.Settings.Default.Carrot_txt = POS_Carrot.ToString();
                var Carrot = Convert.ToInt32(SubTotal_txt.Text);
                Carrot = Carrot + 320;
                double Carrot_Tax = Convert.ToDouble(Tax_txt.Text);
                Carrot_Tax = Carrot_Tax + Carrot * 0.2;
                Tax_txt.Text = Carrot_Tax.ToString();
                SubTotal_txt.Text = Carrot.ToString();

            }
        }

        private void Tomato_POS_Click(object sender, EventArgs e)
        {
            var POS_Tomato = Convert.ToInt32(Properties.Settings.Default.Tomato_txt);
            if (POS_Tomato == 0)
            {
                MessageBox.Show("You are out of Tomato's");
            }
            else
            {
                POS_Receipt.AppendText("Tomato" + "\t\t\t\t\t" + "  510AMD" + Environment.NewLine);
                POS_Tomato = POS_Tomato - 1;
                Properties.Settings.Default.Tomato_txt = POS_Tomato.ToString();
                var Tomato = Convert.ToInt32(SubTotal_txt.Text);
                Tomato = Tomato + 510;
                double Tomato_Tax = Convert.ToDouble(Tax_txt.Text);
                Tomato_Tax = Tomato_Tax + Tomato * 0.2;
                Tax_txt.Text = Tomato_Tax.ToString();
                SubTotal_txt.Text = Tomato.ToString();

            }
        }

        private void Cucumber_POS_Click(object sender, EventArgs e)
        {
            var POS_Cucumber = Convert.ToInt32(Properties.Settings.Default.Cucumber_txt);
            if (POS_Cucumber == 0)
            {
                MessageBox.Show("You are out of Cucumber's");
            }
            else
            {
                POS_Receipt.AppendText("Cucumber" + "\t\t\t\t\t" + "  430AMD" + Environment.NewLine);
                POS_Cucumber = POS_Cucumber - 1;
                Properties.Settings.Default.Cucumber_txt = POS_Cucumber.ToString();
                var Cucumber = Convert.ToInt32(SubTotal_txt.Text);
                Cucumber = Cucumber + 430;
                double Cucumber_Tax = Convert.ToDouble(Tax_txt.Text);
                Cucumber_Tax = Cucumber_Tax + Cucumber * 0.2;
                Tax_txt.Text = Cucumber_Tax.ToString();
                SubTotal_txt.Text = Cucumber.ToString();

            }
        }

        private void Lettuce_POS_Click(object sender, EventArgs e)
        {
            var POS_Lettuce = Convert.ToInt32(Properties.Settings.Default.Lettuce_txt);
            if (POS_Lettuce == 0)
            {
                MessageBox.Show("You are out of Lettuce's");
            }
            else
            {
                POS_Receipt.AppendText("Lettuce" + "\t\t\t\t\t" + "  250AMD" + Environment.NewLine);
                POS_Lettuce = POS_Lettuce - 1;
                Properties.Settings.Default.Lettuce_txt = POS_Lettuce.ToString();
                var Lettuce = Convert.ToInt32(SubTotal_txt.Text);
                Lettuce = Lettuce + 250;
                double Lettuce_Tax = Convert.ToDouble(Tax_txt.Text);
                Lettuce_Tax = Lettuce_Tax + Lettuce * 0.2;
                Tax_txt.Text = Lettuce_Tax.ToString();
                SubTotal_txt.Text = Lettuce.ToString();

            }
        }

        private void Broccoli_POS_Click(object sender, EventArgs e)
        {
            var POS_Broccoli = Convert.ToInt32(Properties.Settings.Default.Broccoli_txt);
            if (POS_Broccoli == 0)
            {
                MessageBox.Show("You are out of Broccoli's");
            }
            else
            {
                POS_Receipt.AppendText("Broccoli" + "\t\t\t\t\t" + "1970AMD" + Environment.NewLine);
                POS_Broccoli = POS_Broccoli - 1;
                Properties.Settings.Default.Broccoli_txt = POS_Broccoli.ToString();
                var Broccoli = Convert.ToInt32(SubTotal_txt.Text);
                Broccoli = Broccoli + 1970;
                double Broccoli_Tax = Convert.ToDouble(Tax_txt.Text);
                Broccoli_Tax = Broccoli_Tax + Broccoli * 0.2;
                Tax_txt.Text = Broccoli_Tax.ToString();
                SubTotal_txt.Text = Broccoli.ToString();

            }
        }

        private void Soy_POS_Click(object sender, EventArgs e)
        {
            var POS_Soy = Convert.ToInt32(Properties.Settings.Default.Soy_txt);
            if (POS_Soy == 0)
            {
                MessageBox.Show("You are out of Soy's");
            }
            else
            {
                POS_Receipt.AppendText("Soy" + "\t\t\t\t\t" + "1500AMD" + Environment.NewLine);
                POS_Soy = POS_Soy - 1;
                Properties.Settings.Default.Soy_txt = POS_Soy.ToString();
                var Soy = Convert.ToInt32(SubTotal_txt.Text);
                Soy = Soy + 1500;
                double Soy_Tax = Convert.ToDouble(Tax_txt.Text);
                Soy_Tax = Soy_Tax + Soy * 0.2;
                Tax_txt.Text = Soy_Tax.ToString();
                SubTotal_txt.Text = Soy.ToString();

            }
        }

        private void Celery_POS_Click(object sender, EventArgs e)
        {
            var POS_Celery = Convert.ToInt32(Properties.Settings.Default.Celery_txt);
            if (POS_Celery == 0)
            {
                MessageBox.Show("You are out of Celery's");
            }
            else
            {
                POS_Receipt.AppendText("Celery" + "\t\t\t\t\t" + "  630AMD" + Environment.NewLine);
                POS_Celery = POS_Celery - 1;
                Properties.Settings.Default.Celery_txt = POS_Celery.ToString();
                var Celery = Convert.ToInt32(SubTotal_txt.Text);
                Celery = Celery + 630;
                double Celery_Tax = Convert.ToDouble(Tax_txt.Text);
                Celery_Tax = Celery_Tax + Celery * 0.2;
                Tax_txt.Text = Celery_Tax.ToString();
                SubTotal_txt.Text = Celery.ToString();

            }
        }

        private void Cabbage_POS_Click(object sender, EventArgs e)
        {
            var POS_Cabbage = Convert.ToInt32(Properties.Settings.Default.Cabbage_txt);
            if (POS_Cabbage == 0)
            {
                MessageBox.Show("You are out of Cabbage's");
            }
            else
            {
                POS_Receipt.AppendText("Cabbage" + "\t\t\t\t\t" + "  270AMD" + Environment.NewLine);
                POS_Cabbage = POS_Cabbage - 1;
                Properties.Settings.Default.Cabbage_txt = POS_Cabbage.ToString();
                var Cabbage = Convert.ToInt32(SubTotal_txt.Text);
                Cabbage = Cabbage + 270;
                double Cabbage_Tax = Convert.ToDouble(Tax_txt.Text);
                Cabbage_Tax = Cabbage_Tax + Cabbage * 0.2;
                Tax_txt.Text = Cabbage_Tax.ToString();
                SubTotal_txt.Text = Cabbage.ToString();

            }
        }

        private void Pumpkin_POS_Click(object sender, EventArgs e)
        {
            var POS_Pumpkin = Convert.ToInt32(Properties.Settings.Default.Pumpkin_txt);
            if (POS_Pumpkin == 0)
            {
                MessageBox.Show("You are out of Pumpkin's");
            }
            else
            {
                POS_Receipt.AppendText("Pumpkin" + "\t\t\t\t\t" + "1090AMD" + Environment.NewLine);
                POS_Pumpkin = POS_Pumpkin - 1;
                Properties.Settings.Default.Pumpkin_txt = POS_Pumpkin.ToString();
                var Pumpkin = Convert.ToInt32(SubTotal_txt.Text);
                Pumpkin = Pumpkin + 990;
                double Pumpkin_Tax = Convert.ToDouble(Tax_txt.Text);
                Pumpkin_Tax = Pumpkin_Tax + Pumpkin * 0.2;
                Tax_txt.Text = Pumpkin_Tax.ToString();
                SubTotal_txt.Text = Pumpkin.ToString();

            }
        }
    }
}
